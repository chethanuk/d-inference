# Independent on2 semantic and measurement review

Report SHA256: `cae084b14793bf8cafc7f8433ecbb1b465d6c34c2fff180f92003ac95042b57a`. Copied after `structural-verdict.json` was present and passed with zero errors. Review is CPU-only on retained outputs and source records; no additional model execution. Matched off arm is pending. No release-acceptance or general quality-equivalence conclusion follows from this arm.

| Row | Decode tok/s | TTFT ms | Restored tokens | MTP rounds | Seeds | SSD bytes read |
|---|---:|---:|---:|---:|---:|---:|
| code-first | 126.49 | 1816.0 | 0 | 525 | 3 | 0 |
| code-repeat | 123.35 | 206.3 | 8192 | 426 | 9 | 377627384 |
| prose-first | 117.55 | 992.2 | 0 | 120 | 8 | 0 |
| prose-repeat | 117.60 | 257.6 | 4096 | 120 | 8 | 293680866 |
| extraction-first | 135.39 | 1343.6 | 0 | 511 | 1 | 0 |
| extraction-repeat | 136.23 | 180.8 | 6144 | 511 | 1 | 335654642 |

Every row reaches the 1,024-token cap (`finish=length`), with 1,023 tokens measured after first delta over 7.51–8.70 seconds. First rows are cold misses with no reads; repeated rows consume one staged checkpoint each, read two files each, and replay zero tokens. All measured MTP rounds are rectangular. Prose falls back substantially to ordinary decoding; sustained carry reuse is observed for code/extraction. These are absolute on-arm results, not gains against an unmeasured off baseline.

## Code

Both complete implementation prefixes reproduce the September 8 source-isolation defect. Inserting equal event IDs for source A and source B returns true then false, leaving aggregate 10 instead of required 20. The code explicitly adds global event-ID conflict handling despite the requested `(source,event_id)` identity. This error precedes the cap and is not an artifact of unfinished tests.

Both implementations parse ISO timestamps but accept timezone-naive values, contrary to the timezone-aware requirement. Identical retry and conflicting retry both return false without changing the first reading; conflict rejection is present, but there is no explicit distinction between those outcomes. Per-source retrieval sorts by sequence, the frozen dataclass is present, and the valid-reading aggregate excludes other quality values. Validation remains limited; substantive unittest coverage and final explanation are truncated.

`semantic-probes.json` records executable results. Only inspected, unmodified complete definitions before `class TestEventLedger` were executed; the truncated generated test tail was excluded. The original output files remain unchanged. Code-first/repeat differ, beginning at generated-token position146, while receiving identical prompt tokens. This does not independently identify cache corruption.

## Prose

The two outputs are text-identical. They preserve all five district concerns: Orchard bus arrival information, Hill school crossings, Canal drainage, West shop access and Harbor shade. The memo explicitly separates suggestions from approval/funding; it proposes a limited pilot, published review, measures and phased decisions, with no invented survey statistics. It is cut mid-final recommendation at the cap.

Retain minor grounding limitations: the author/date are invented memo framing, and Orchard's attribution to “transit users” broadens the source's teachers group. The claimed cross-district drainage/shop-access tension is a hypothetical implementation risk rather than an established connection in the records. The suggested transit metric measures schedule adherence rather than directly measuring information accuracy. These points limit a blanket factual-quality pass but do not erase the substantive planning coverage.

## Extraction

Both outputs are text-identical. All 72 fields in eight complete objects P001–P008 match the source exactly, including integer budgets and approval notes. P009 is incomplete and P010–P018 absent because of the cap. Despite the instruction to return JSON only and complete full objects when space is limited, the output starts with a Markdown JSON fence and ends mid-object; the full response is not parseable JSON. The field-level pass therefore applies only to complete objects, not whole-output task completion.

## Lifecycle and identity limits

The structural checker passed its tenant/cancellation/retirement checks under generation-comparison policy `record`; exact generated-token mismatches remain recorded rather than hidden. Final retirement reports ready, with zero process ledger owners/charges and zero paged live/committed/reserved bytes. SSD stage/write host usage is zero after shutdown. The post-shutdown cache-status error is not used here to negate successful live read counters; interpretation belongs to lifecycle status semantics.

Reported binary SHA256 is `a0f953b83ef8bd65d0dbbd3d442557cb0b35fff80ce63281d436d33ea64d0bf1`; reported metallib SHA256 is `20972c37e53fe6db3b3191a0434f6604c4ffc4f5ac62b370574f9922585b0fdb`. The metallib was rebuilt from pinned MLX core `3fa8f25e6451174d7b06be372c3a24272b77d88e` and is byte-identical to the September 8 artifact. The build owner confirmed the canonical rebuilt artifact, frozen identity and reported binary/metallib identity; equal hashes are expected, not an unresolved mismatch. This CPU-only review relies on that retained build/identity evidence.
