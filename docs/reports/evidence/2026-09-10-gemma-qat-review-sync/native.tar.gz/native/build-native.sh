#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gemma-qat-review-sync-20260910
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export RADIX_SOURCE_ROOT="$root/workspace"
export RADIX_CANDIDATE_BUILD=1
tar -xzf "$root/native-source.tar.gz" -C "$root/workspace"
python3 - "$root" <<'PYVERIFY'
from pathlib import Path
import json,hashlib,sys
r=Path(sys.argv[1]);m=json.loads((r/'native-source-manifest.json').read_text());bad=[f['path'] for f in m['files'] if hashlib.sha256((r/'workspace'/f['path']).read_bytes()).hexdigest()!=f['sha256']];assert not bad,bad
print('Native source verified',m['native'],len(m['files']))
PYVERIFY
python3 -B "$root/prepare_native_tests_harness.py" --workspace "$root/workspace" --output "$root/native-tests-harness"
python3 - "$root" <<'PYHARNESS'
from pathlib import Path
import shutil,sys
r=Path(sys.argv[1]);h=r/'native-tests-harness';lm=r/'workspace/libs/mlx-swift-lm'
shutil.copytree(lm/'Tests/OnboardingQualificationTests',h/'Tests/OnboardingQualificationTests')
server=h/'Tests/ServerParserTests';server.mkdir()
for name in ['NemotronToolFrameTests.swift','ReasoningParserTests.swift','ToolCallTemplateArgumentsTests.swift','ToolCallParserIntegrationTests.swift']:
 shutil.copy2(lm/'Tests/MLXLMServerTests'/name,server/name)
f=h/'Package.swift';t=f.read_text();t=t.replace('\n    ]\n)', '\n        , .testTarget(name: "OnboardingQualificationTests", dependencies: [\n            .product(name: "MLX", package: "mlx-swift"),\n            .product(name: "MLXNN", package: "mlx-swift"),\n            .product(name: "MLXLMCommon", package: "mlx-swift-lm"),\n            .product(name: "MLXLLM", package: "mlx-swift-lm")], path: "Tests/OnboardingQualificationTests"),\n        .testTarget(name: "ServerParserTests", dependencies: [\n            .product(name: "MLXLMServer", package: "mlx-swift-lm"),\n            .product(name: "MLXLMCommon", package: "mlx-swift-lm")], path: "Tests/ServerParserTests")\n    ]\n)');f.write_text(t)
PYHARNESS
cd "$root/native-tests-harness"
xcrun swift build --force-resolved-versions -c release --build-tests --scratch-path "$root/release-build" --jobs 4 -Xswiftc -enable-testing > "$root/logs/native-test-build.log" 2>&1
cp -c "$root/artifact/mlx.metallib" "$root/release-build/arm64-apple-macosx/release/GemmaPrefixNativeTestsPackageTests.xctest/Contents/MacOS/mlx.metallib"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter 'CBv2MTP|CBv2QwenMTPIntegrationTests|CBv2PagedQueryBlockingTests|CBv2PagedSpeculativeRowTests|HistoricalWindowCheckpoint|PagedCompleteCheckpointCodecTests|CBv2CompleteCheckpointEngineTests|CompleteCheckpointMetadataOwnershipTests|GatedDeltaTests|NemotronHTests|NemotronH35BackendParityTests|NemotronH35GraphCacheTests|NemotronH35MTPPrimingTests|NemotronH35MTPTests|NemotronH35ProductionDefaultsTests|NemotronH35SSMWindowTests|PagedMTPBatchedColumnsTests|SSMDecodeBoundsTests|MutableInputExportTests|MutableInputKernelTests|CBv2PagedSegmentReadbackBoundaryTests|NemotronToolFrameTests|ReasoningParserTests|ToolCallTemplateArgumentsTests|ToolCallParserIntegrationTests' > "$root/logs/native-tests.log" 2>&1
printf PASS > "$root/native-result.txt"
