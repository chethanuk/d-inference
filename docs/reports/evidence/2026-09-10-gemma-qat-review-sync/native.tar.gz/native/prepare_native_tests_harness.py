"""Stage a normal SwiftPM root harness over exact local LM/Swift dependencies.
Only writes the explicitly new output directory; never builds or changes source.
"""
import argparse,hashlib,json,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--output',required=True);p.add_argument('--swift-source');a=p.parse_args()
src=Path(a.workspace).resolve();out=Path(a.output).resolve();lm=src/'libs/mlx-swift-lm';swift=Path(a.swift_source).resolve() if a.swift_source else src/'libs/mlx-swift'
if out.exists():raise SystemExit('fresh harness directory required')
for path in [lm/'Package.swift',swift/'Package.swift',src/'provider-swift/Package.resolved']:
 if not path.is_file():raise SystemExit('missing pinned source/lock: '+str(path))
resources=['Resources/1080p_30.mov','Resources/audio_only.mov','Resources/Gemma4MTPPrompts.json','Resources/gemma4-26B-A4B-assistant-config.json','Resources/gemma4-E4B-assistant-config.json','Resources/mtp-oracle/gemma4-e2b-block3-max64.json','Resources/block_hash_vectors.json']
manifest=(lm/'Package.swift').read_text()
for value in resources+['Gemma4VLMMTPSpikeTests.swift']:
 if '"'+value+'"' not in manifest:raise SystemExit('native test resource/exclusion contract changed: '+value)
out.mkdir(parents=True)
shutil.copytree(lm/'Tests/MLXLMTests',out/'Tests/MLXLMTests',symlinks=False)
shutil.copy2(src/'provider-swift/Package.resolved',out/'Package.resolved')
quote=lambda x:json.dumps(str(x))
products=[(n,'mlx-swift') for n in ['MLX','MLXNN','MLXOptimizers']]+[(n,'mlx-swift-lm') for n in ['MLXLMCommon','MLXLLM','MLXVLM','MLXEmbedders']]
deps=',\n                '.join('.product(name: '+quote(n)+', package: '+quote(package)+')' for n,package in products)
res=',\n                '.join('.process('+quote(n)+')' for n in resources)
(out/'Package.swift').write_text('''// swift-tools-version: 6.1
import PackageDescription

// Direct root dependencies override LM's remote Swift dependency with this
// exact local checkout through ordinary SwiftPM graph resolution.
// ResolveTests exercises package-scoped model path resolution; this external
// focused CBv2 harness cannot access that unrelated package-only API.
let package = Package(
    name: "GemmaPrefixNativeTests",
    platforms: [.macOS(.v14)],
    dependencies: [
        .package(path: '''+quote(swift)+'''),
        .package(path: '''+quote(lm)+'''),
    ],
    targets: [
        .testTarget(
            name: "MLXLMTests",
            dependencies: [
                '''+deps+'''
            ],
            path: "Tests/MLXLMTests",
            exclude: ["README.md", "Gemma4VLMMTPSpikeTests.swift", "ResolveTests.swift"],
            resources: [
                '''+res+'''
            ]
        )
    ]
)
''')
files={str(f.relative_to(out)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(out.rglob('*')) if f.is_file()}
(out/'harness-manifest.json').write_text(json.dumps({'source_workspace':str(src),'lm_package_sha256':hashlib.sha256((lm/'Package.swift').read_bytes()).hexdigest(),'swift_package_sha256':hashlib.sha256((swift/'Package.swift').read_bytes()).hexdigest(),'files':files,'build_executed':False,'test_executed':False},indent=2)+'\n')
print(json.dumps({'output':str(out),'files':len(files),'byte_total':sum(x['bytes'] for x in files.values())}))
