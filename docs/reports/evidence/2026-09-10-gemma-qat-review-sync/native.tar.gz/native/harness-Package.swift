// swift-tools-version: 6.1
import PackageDescription

// Direct root dependencies override LM's remote Swift dependency with this
// exact local checkout through ordinary SwiftPM graph resolution.
// ResolveTests exercises package-scoped model path resolution; this external
// focused CBv2 harness cannot access that unrelated package-only API.
let package = Package(
    name: "GemmaPrefixNativeTests",
    platforms: [.macOS(.v14)],
    dependencies: [
        .package(path: "/Users/gaj/autoresearch/gemma-qat-review-sync-20260910/workspace/libs/mlx-swift"),
        .package(path: "/Users/gaj/autoresearch/gemma-qat-review-sync-20260910/workspace/libs/mlx-swift-lm"),
    ],
    targets: [
        .testTarget(
            name: "MLXLMTests",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift"),
                .product(name: "MLXOptimizers", package: "mlx-swift"),
                .product(name: "MLXLMCommon", package: "mlx-swift-lm"),
                .product(name: "MLXLLM", package: "mlx-swift-lm"),
                .product(name: "MLXVLM", package: "mlx-swift-lm"),
                .product(name: "MLXEmbedders", package: "mlx-swift-lm")
            ],
            path: "Tests/MLXLMTests",
            exclude: ["README.md", "Gemma4VLMMTPSpikeTests.swift", "ResolveTests.swift"],
            resources: [
                .process("Resources/1080p_30.mov"),
                .process("Resources/audio_only.mov"),
                .process("Resources/Gemma4MTPPrompts.json"),
                .process("Resources/gemma4-26B-A4B-assistant-config.json"),
                .process("Resources/gemma4-E4B-assistant-config.json"),
                .process("Resources/mtp-oracle/gemma4-e2b-block3-max64.json"),
                .process("Resources/block_hash_vectors.json")
            ]
        )
        , .testTarget(name: "OnboardingQualificationTests", dependencies: [
            .product(name: "MLX", package: "mlx-swift"),
            .product(name: "MLXNN", package: "mlx-swift"),
            .product(name: "MLXLMCommon", package: "mlx-swift-lm"),
            .product(name: "MLXLLM", package: "mlx-swift-lm")], path: "Tests/OnboardingQualificationTests"),
        .testTarget(name: "ServerParserTests", dependencies: [
            .product(name: "MLXLMServer", package: "mlx-swift-lm"),
            .product(name: "MLXLMCommon", package: "mlx-swift-lm")], path: "Tests/ServerParserTests")
    ]
)
