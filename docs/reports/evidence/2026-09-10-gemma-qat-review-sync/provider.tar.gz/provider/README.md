# September 10 provider and benchmark tests

**PASS:** provider 345 Swift Testing tests in 32 suites and 0 XCTest tests; benchmark 31 Swift Testing tests in 9 suites and 2 XCTest tests. No failure or skip events were recorded.

[Summary and actual test/suite inventories](summary.json), [provider tests](provider-tests.log.gz), [benchmark tests](benchmark-tests.log.gz), [provider test build](provider-test-build.log.gz), and [benchmark test build](benchmark-test-build.log.gz). Build warnings are retained, not suppressed.

The expanded filter actually ran all **11** previously missing suites and all **47** intended top-level tests. The summary preserves each pass-line number. It also identifies the unmatched legacy `BenchmarkPromptContractTests` filter token without claiming coverage. The actual [execution script](build-provider.sh) is included.

This evidence covers the selected provider fixtures and benchmark package tests. It does not establish real-model speed, serving behavior, or physical fleet equivalence. The [initial failed build](initial-77df/summary.json) and [raw failed log](initial-77df/provider-test-build.log.gz) preserve all three exhaustive-switch errors. Test-only fix `fe423c033a4c06151bbda157ed87ec58db898778` added `.parsed` handling without deleting assertions; that is the source export used for the passing run. Live Gemma/Qwen canary files compiled but their real-model suites were not selected.
