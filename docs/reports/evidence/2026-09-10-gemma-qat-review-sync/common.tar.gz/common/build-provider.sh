#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gemma-qat-review-sync-20260910
release="$root/release-build/arm64-apple-macosx/release"
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export RADIX_SOURCE_ROOT="$root/workspace"
export RADIX_CANDIDATE_BUILD=1
[ "$(cat "$root/native-result.txt")" = PASS ]
tar -xzf "$root/source.tar.gz" -C "$root/workspace"
python3 - "$root" <<'VERIFY'
import hashlib,json,pathlib,sys
r=pathlib.Path(sys.argv[1]);m=json.loads((r/'source-manifest.json').read_text())
bad=[x['path'] for x in m['files'] if hashlib.sha256((r/'workspace'/x['path']).read_bytes()).hexdigest()!=x['sha256']]
assert not bad,bad
old=json.loads((r/'native-source-manifest.json').read_text())
assert all(hashlib.sha256((r/'workspace'/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in old['files'])
print('Full source and unchanged tested native verified',m['parent_head'],m['lm_head'],len(m['files']))
VERIFY
cd "$root/workspace/scripts/benchmarks/radix-engine"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/release-build" --jobs 4 --product radix-engine > "$root/logs/native-product-build.log" 2>&1
cd "$root/workspace/provider-swift"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/release-build" --jobs 4 --product darkbloom > "$root/logs/provider-build.log" 2>&1
cp -c "$release/radix-engine" "$release/darkbloom" "$root/artifact/"
for bundle in "$release/"*.bundle; do cp -cR "$bundle" "$root/artifact/"; done
shasum -a 256 "$root/artifact/radix-engine" "$root/artifact/darkbloom" "$root/artifact/mlx.metallib" > "$root/artifact-sha256.txt"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/release-build" --jobs 4 --build-tests -Xswiftc -enable-testing > "$root/logs/provider-test-build.log" 2>&1
cp -c "$root/artifact/mlx.metallib" "$release/mlx.metallib"
cp -c "$root/artifact/mlx.metallib" "$release/DarkbloomProviderPackageTests.xctest/Contents/MacOS/mlx.metallib"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter 'PrefixCachePolicyTests|PrefixCacheLoadHashTests|EngineV2KVBackendGateTests|MTPConfigTests|EngineV2ProductionWiringTests|ProviderMTPFactoryTests|EngineV2BenchmarkMTPVerificationTests|SpecDecArtifactFunnelTests|BenchmarkProductionInputTests|BenchmarkPromptContractTests|SpecDecHuggingFaceTests|HuggingFaceDownloadTests|SpecDecResolverTests|MTPIdleUpgradeTests|ProviderLoopMTPUpgradeTests|MTPStagingReservationsTests|MTPResliceFallbackTests|StandaloneMTPPreparationTests|StandaloneMTPUpgradeTests|MTPPostureTelemetryTests|LiveInferenceMetallibSourceTests|EngineV2Reslice|ModelLoadAdmission|GlobalKVCacheBudget|SSDCacheEpochStore|CancelledSettlementLifecycle|EngineV2SlotBuildTests|EngineV2ReslicingWiringTests|EngineV2RequestRoutingTests|EngineV2RuntimeGuardTests|EngineV2KVBackendFallbackHeartbeatTests|PrefillDeadlineProductionConfigTests|MTPConfigKeyTests|MTPBetaFeatureTests|MTPSupportedModelsTests|InlineDeclarationProbeTests|SingleProbeInlineDecisionTests|globalKVCacheBudgetRejectsDuplicateReservationIDs|globalKVCacheBudgetRejectsOverflowingReservationSize|globalKVCacheBudgetReconcilesExactByteReservationsAtomically|globalKVCacheBudgetHonorsCapFractionAsTotalReservationCap|globalKVCacheBudgetClampsToOSAvailableWhenItIsTighter|globalKVCacheBudgetUsesMLXViewWhenItIsTighterThanOS|globalKVCacheBudgetSubtractsActivationReserveFromHeadroom|pendingLoadReservationBlocksConcurrentKVOverCommit|globalKVCacheBudgetHonorsOperatorReserveAboveCapImplied|providerLoopMemoryReserveBytesSaturatesOnOverflow|globalKVCacheBudgetHonorsAReplacedActivationReserve|globalKVCacheBudgetDiscardsStaleEpochReservePushes|admissionRejectsNearMissOnCurrentSnapshotInsteadOfFlushingInline|reserveBytesRejectsNearMissOnCurrentSnapshot|admissionDoesNotBlockTheActorOnTheReclaimFlush|admissionAdmitsImmediatelyWhenItFitsWithoutAnyFlush|processBudgetNativeCoverageKeepsLoadHeadroomExact|processBudgetLoadReservePreservesOSLimitedPolicyWithoutChangingRuntime|processBudgetLoadAllowanceSurvivesTargetAndAssistantPhaseCompletion|processBudgetDelayedLoadCleanupCannotCloseSameIDSuccessor|processBudgetPolicyRecheckRetainsTheWholeAcceptedLoad|processBudgetOptionalAssistantCannotSpendTargetOnlyHeadroom|processBudgetLoadClaimAndNativeGrowthCompeteAtOneLock|processBudgetNativeClosingKeepsPreviouslyReservedAllocationsSafe|freeForLoadHasNoSafetyDiscount|freeForLoadSubtractsResidentAndReserve|requiredToLoadIsWeightsPlusHeadroom|gptOssLoadsOn24GB|gemma8bitRejectedOn32GB|gemmaLoadsOn64GB|cannotLoadWhenAnotherModelIsResident|freeIsClampedToRealSystemAvailable|systemClampBlocksLoadThatMlxViewWouldAllow|outstandingReservationsReduceFree|outstandingReservationsCanBlockASecondLoad|idleBoxStillLoadsGptOssWithClamps|maxLoadableWeightReclaimsIdleModels|maxLoadableWeightClampsToSystemAvailable|maxLoadableWeightFloorsAtZero|maxLoadableWeightSubtractsOutstandingReservations|maxLoadableWeightMirrorsCanLoadWhenIdle|backendCapacityRoundTripsFreeForLoad|backendCapacityDecodesLegacyWithoutFreeForLoad|evictionCanReachRefusesHopelessEvictions|standaloneAssistantCatalogUsesConfiguredCoordinatorAuthority|standaloneAutomaticQATAssistantSchedulesCatalogWithoutBlockingTargetPreparation|standaloneOffAndOtherAutomaticGemmaDoNotFetchAssistants' > "$root/logs/provider-tests.log" 2>&1
printf PASS > "$root/provider-result.txt"
cd "$root/workspace/scripts/benchmarks/radix-engine"
xcrun swift build --force-resolved-versions -c release --build-tests --scratch-path "$root/release-build" --jobs 4 -Xswiftc -enable-testing > "$root/logs/benchmark-test-build.log" 2>&1
cp -c "$root/artifact/mlx.metallib" "$release/RadixEngineBenchmarkPackageTests.xctest/Contents/MacOS/mlx.metallib"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing > "$root/logs/benchmark-tests.log" 2>&1
printf PASS > "$root/benchmark-result.txt"
printf PASS > "$root/build-result.txt"
