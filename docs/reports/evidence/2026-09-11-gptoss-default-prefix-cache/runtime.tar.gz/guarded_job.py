"""Run one owned sequential validation job; preserve results on interruption."""
import argparse,json,subprocess,time,signal,sys,os
from pathlib import Path
from guarded_build import blockers,terminate_owned as kill_owned_group

def terminate_owned(proc):
 # Wrappers own nested process groups and need time to run their finally blocks.
 if proc is None or proc.poll() is not None:return
 try:os.killpg(proc.pid,signal.SIGTERM)
 except ProcessLookupError:return
 try:proc.wait(timeout=20)
 except subprocess.TimeoutExpired:kill_owned_group(proc)

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--name',required=True);p.add_argument('--cwd',type=Path);p.add_argument('--maximum-seconds',type=int,default=900);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
 assert Path(a.name).name==a.name and a.name not in ['.','..']
 cmd=a.command[1:] if a.command and a.command[0]=='--' else a.command
 assert cmd
 root=a.root.resolve();logs=root/'job-logs';logs.mkdir(exist_ok=True);path=logs/(a.name+'.json')
 assert not path.exists(),'Preserve prior attempt; use fresh name'
 status={'name':a.name,'started_unix':time.time(),'command':cmd,'status':'starting'};proc=None;interrupted=[]
 for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,lambda sig,frame:interrupted.append(sig))
 try:
  active=blockers()
  if active:status.update(status='refused',blockers=active);return 75
  with (logs/(a.name+'.log')).open('w') as stream:
   proc=subprocess.Popen(cmd,cwd=a.cwd,start_new_session=True,stdout=stream,stderr=subprocess.STDOUT);status['owned_pgid']=proc.pid
   deadline=time.monotonic()+a.maximum_seconds
   while proc.poll() is None:
    active=blockers(proc.pid)
    reason='foreign ranked job' if active else 'interrupted' if interrupted else 'time bound' if time.monotonic()>deadline else None
    if reason:
     status.update(status='aborted',reason=reason,blockers=active);terminate_owned(proc);return 75
    time.sleep(1)
   status.update(status='passed' if proc.returncode==0 else 'failed',process_exit_code=proc.returncode);return proc.returncode
 finally:
  if proc is not None and proc.poll() is None:terminate_owned(proc)
  status['ended_unix']=time.time();path.write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status))
if __name__=='__main__':sys.exit(main())
