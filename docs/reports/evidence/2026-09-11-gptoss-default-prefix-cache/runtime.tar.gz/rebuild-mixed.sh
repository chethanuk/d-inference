#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gptoss-prefix-20260911
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
unset MLX_ENABLE_TF32 DARKBLOOM_LIVE_MLX_TESTS
cd "$root/workspace/provider-swift"
python3 -B "$root/verify_source.py" "$root"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/release-build" --jobs 4 --build-tests -Xswiftc -enable-testing > "$root/logs/provider-test-build-revision3.log" 2>&1
release="$root/release-build/arm64-apple-macosx/release"
cp -c "$root/artifact/mlx.metallib" "$release/mlx.metallib"
cp -c "$root/artifact/mlx.metallib" "$release/DarkbloomProviderPackageTests.xctest/Contents/MacOS/mlx.metallib"
cp -c "$release/darkbloom" "$root/artifact/darkbloom"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter 'PrefixCache|SSDHybrid|GPTOSS|EngineV2KVBackendGate|EngineV2ProductionWiring' --skip 'GPTOSSPrefillOutputTests|CBv2Gemma4ScheduledPrefillTests' > "$root/logs/provider-tests-revision3.log" 2>&1
printf PASS > "$root/provider-result.txt"
python3 -B "$root/verify_source.py" "$root"
shasum -a 256 "$root/artifact/darkbloom" "$root/artifact/radix-engine" "$root/artifact/mlx.metallib" > "$root/artifact-sha256.txt"
test "$(cat "$root/benchmark-result.txt")" = PASS
printf PASS > "$root/build-result.txt"
