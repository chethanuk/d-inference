from pathlib import Path
import argparse,hashlib,json,tarfile
p=argparse.ArgumentParser();p.add_argument('--name',required=True);a=p.parse_args()
root=Path('/Users/gaj/autoresearch/gptoss-prefix-20260911');target=root/(a.name+'.tar.gz')
assert not target.exists()
selected=set()
for name in ['source-manifest.json','source-proof.json','artifact-sha256.txt','commit-source-binding.json','guard-status.json','target-manifest.json','target-download-verification.json','target-download-attempts.jsonl','build-result.txt','provider-result.txt','benchmark-result.txt','test-bundle-sha256.txt']:
 f=root/name
 if f.is_file():selected.add(f)
for directory in ['logs','job-logs','initial-build','revision2-build','revision3-build','pre-final-source','validation','validation-before-harmony-fix','http','http-before-owned-child-fix','http-before-final-channel-fix']:
 d=root/directory
 if d.exists():
  for f in d.rglob('*'):
   if f.is_file() and not f.is_symlink() and '__pycache__' not in f.parts: selected.add(f)
for d in (root/'results').iterdir():
 if d.is_file():selected.add(d)
 elif d.is_dir():
  for f in d.iterdir():
   if f.is_file() and not f.is_symlink() and f.suffix in {'.json','.jsonl','.log','.txt','.toml'}:selected.add(f)
for name in ['guarded_build.py','guarded_job.py','verify_source.py','build-provider-inner.sh','build-benchmark.sh','rebuild-provider.sh','rebuild-mixed.sh','rebuild-scope.sh','run-checkpoint.sh','run-mixed.sh','run-matrix-cell.sh','amend-mixed-source.py','amend-scope-source.py','package_evidence.py']:
 f=root/name
 if f.is_file():selected.add(f)
inventory=[{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(selected)]
(root/(a.name+'-inventory.json')).write_text(json.dumps(inventory,indent=2)+'\n')
with tarfile.open(target,'w:gz') as archive:
 for f in sorted(selected):archive.add(f,arcname=str(f.relative_to(root)),recursive=False)
print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(inventory)}))
