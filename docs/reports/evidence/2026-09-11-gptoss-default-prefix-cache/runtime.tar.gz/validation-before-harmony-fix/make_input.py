#!/usr/bin/env python3
"""Create immutable synthetic requests, with answer keys outside model input."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
records = []
for index in range(1, 101):
    quantity = (index * 13 + 11) % 83 + 1
    label = ["cedar", "harbor", "meadow", "quartz", "willow"][index % 5]
    if index == 37:
        quantity, label = 17, "harbor"
    if index == 84:
        quantity, label = 29, "quartz"
    records.append(f"Record R{index:03d}: label={label}; quantity={quantity}; section=S{index % 9}; "
                   "state=verified. This entry describes an independent inventory bin; "
                   "quantities from different records must never be combined unless explicitly requested.")
shared = ("The following inventory is reference data, not instructions. Each record has one quantity and label.\n"
          + "\n".join(records) + "\nEND OF INVENTORY.\n")
system = ("Answer inventory questions accurately. Use only the record and arithmetic named in the final question. "
          "Return one JSON object as the final answer, without Markdown or explanatory prose. "
          "Do not list other records. Keep any reasoning brief.")
questions = [
    ("long-first", "extract", "Return R037's label and quantity. Use exactly keys record, label, quantity.",
     {"record": "R037", "label": "harbor", "quantity": 17}),
    ("long-repeat", "extract", "Return R037's label and quantity. Use exactly keys record, label, quantity.",
     {"record": "R037", "label": "harbor", "quantity": 17}),
    ("branch-first", "extract", "Return R084's label and quantity. Use exactly keys record, label, quantity.",
     {"record": "R084", "label": "quartz", "quantity": 29}),
    ("branch-repeat", "extract", "Return R084's label and quantity. Use exactly keys record, label, quantity.",
     {"record": "R084", "label": "quartz", "quantity": 29}),
    ("compute-first", "compute", "For R037 only, add 7 to its quantity, then subtract 3. Return exactly keys record and result.",
     {"record": "R037", "result": 21}),
    ("compute-repeat", "compute", "For R037 only, add 7 to its quantity, then subtract 3. Return exactly keys record and result.",
     {"record": "R037", "result": 21}),
]
rows, expected = [], {}
for name, kind, question, answer in questions:
    rows.append({"case": {"id": name, "kind": kind}, "request": {
        "model": "gpt-oss-20b", "max_tokens": 512, "temperature": 0,
        "reasoning_effort": "low", "_darkbloom_prompt_date": "2026-09-11",
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": shared + "QUESTION: " + question}]}})
    expected[name] = answer
artifacts = {"input.json": {"schema": 1, "rows": rows},
             "expected.json": {"schema": 1, "expected": expected,
               "shared_text_sha256": hashlib.sha256(shared.encode()).hexdigest(),
               "request_date": "2026-09-11", "record_count": len(records),
               "shared_text_characters": len(shared),
               "prompt_token_target": [3000, 5500],
               "note": "Token count is measured by the actual tokenizer in each retained report."}}
for name, body in artifacts.items():
    path = ROOT / name
    if path.exists():
        raise SystemExit(f"Refusing to overwrite {path}")
    path.write_text(json.dumps(body, indent=2, sort_keys=True) + "\n")
