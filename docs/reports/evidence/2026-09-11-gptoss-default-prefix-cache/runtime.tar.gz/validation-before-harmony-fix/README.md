# GPT-OSS prefix-cache validation input

Prepared 2026-09-11. No model execution has been performed by this preparation task.

`input.json` contains six requests with a shared inventory (~20.6k characters;
actual token length must come from the retained model report), three distinct
suffixes, and paired repeats. Two tasks extract different records; the third
performs a small computation. Answer keys exist only in `expected.json`, never
as a repeated canary in every inventory record. Each request pins the date,
temperature 0, reasoning effort low, and at most 512 output tokens.

Run on the dedicated M5 only, sequentially. Use the root-owned exact candidate
artifact and verified model directory/hash. This speed matrix uses an ephemeral
test encryption key, avoiding unsigned-test Keychain access. Repeat these two commands for N = 1, 2, 4, with fresh
output paths; each default output owns a fresh cache directory.

```sh
python3 -B scripts/benchmarks/run_radix_engine.py \
  --binary "$RADIX_BINARY" --model-directory "$MODEL_DIRECTORY" \
  --input /path/to/validation/input.json --output /path/to/results/bN-on \
  --cache on --mtp off --kv-backend paged --cache-mode ssd --key-mode ephemeral \
  --production-kv-grant --expected-model-sha256 "$MODEL_SHA256" \
  --prompt-date 2026-09-11 --concurrency N --generation-comparison-policy record

python3 -B scripts/benchmarks/run_radix_engine.py \
  --binary "$RADIX_BINARY" --model-directory "$MODEL_DIRECTORY" \
  --input /path/to/validation/input.json --output /path/to/results/bN-off \
  --cache off --mtp off --kv-backend paged --cache-mode ssd --key-mode ephemeral \
  --production-kv-grant --expected-model-sha256 "$MODEL_SHA256" \
  --prompt-date 2026-09-11 --concurrency N --generation-comparison-policy record

python3 -B /path/to/validation/validate.py \
  --benchmarks /path/to/repo/scripts/benchmarks \
  --on /path/to/results/bN-on/report.json --off /path/to/results/bN-off/report.json \
  --output /path/to/results/bN-validation.json
```

`validate.py` imports the existing structural evidence checker and adds an
independent JSON-answer oracle, paired-input checks, direct authenticated cache
hit requirements, cold-first assertions, and TTFT/decode timing summaries.
Every suffix cohort after the first must contain an actual authenticated hit;
safe misses in individual concurrent rows are retained. All answers and control
answers must match their own suffix. Truncation fails semantic qualification.
Generated-token equality is recorded but does not decide semantic success.

The harness already exercises tenant isolation and cancel-after-restoration
followed by recovery. Its B2/B4 path duplicates a single prompt per cohort;
different suffixes run in successive cohorts. It does not cover mixed suffixes
in one simultaneous cohort, HTTP, coordinator routing, or process restart.
The speed matrix does not prove persistent-key recovery across processes.
Engine reconstruction with the same injected key is tested by a separate
provider fixture; it is distinct from a real persistent-Keychain restart.
Separate-process persistent restart must use a separate result and oracle,
because this validator deliberately requires the first cohort to be cold.

These are bounded synthetic tasks, not broad model-quality qualification.
Few-request timing distributions do not establish statistical significance.
The existing harness has a 30-minute bound per cell and dedicated-host checks;
root remains responsible for sequential ownership and current host availability.
