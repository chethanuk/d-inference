"""Pure oracle regressions. These synthesized rows are never benchmark evidence."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

import validate

EXPECTED = validate.load(Path(__file__).with_name("expected.json"))["expected"]

def fixture(concurrency=1, enabled=True):
    # Field names and optional values match BenchmarkGeneration/Sampling.
    rows = []
    for name, answer in EXPECTED.items():
        branch = 1 if name.startswith("long") else 2 if name.startswith("branch") else 3
        for i in range(concurrency):
            restored = enabled and name != "long-first"
            rows.append({"id": name + (f"-b{i}" if concurrency > 1 else ""),
                "scope": "tenant-A", "outcome": "completed", "finish": "stop",
                "text": '<|channel|>analysis<|im_sep|>Read the named record. '
                        '<|channel|>final<|im_sep|>' + json.dumps(answer) + '<|fim_suffix|>',
                "prompt_render_date": "2026-09-11", "prompt_token_ids": [7] * 3000 + [branch],
                "token_ids": [123, 456], "prompt_tokens": 3001, "completion_tokens": 2,
                "sampling": {"temperature": 0, "seed": None, "top_p": 1, "top_k": 0,
                    "min_p": 0, "repetition_penalty": 1, "repetition_context_size": 64,
                    "frequency_penalty": 0, "presence_penalty": 0, "logit_bias": {}, "top_logprobs": 0},
                "ttft_s": .5 if restored else 2., "decode_tps": 10.,
                "cache_outcome": "hit" if restored else "miss", "saved_tokens": 2048 if restored else 0,
                "matched_tokens": 2048 if restored else 0, "replay_tokens": 0,
                "strategy": "direct" if restored else None,
                "ssd_stage_disposition": "staged" if restored else "not_attempted",
                "metrics_before": {"ssd_cache": {"stage_read_bytes": 100}},
                "metrics_after": {"ssd_cache": {"stage_read_bytes": 200 if restored else 100}}})
    control = copy.deepcopy(next(row for row in rows if row["id"].startswith("compute-first")))
    control["id"] = "compute-first"  # controls keep Input.name, not the UUID scope
    tenants = [dict(copy.deepcopy(control), scope=scope) for scope in ("probe-uuid-A", "probe-uuid-A", "probe-uuid-B")]
    return {"schema": 3, "model": "gpt-oss-20b", "status": "completed", "rows": rows,
        "key_mode_requested": "ephemeral", "metrics_loaded": {"key_mode": "ephemeral" if enabled else None},
        "max_concurrent_requests": concurrency, "resolved_backend": "paged", "cache_requested": enabled,
        "mtp": "off; no drafter supplied", "tenant_checks": tenants,
        "cancel_donor": dict(copy.deepcopy(control), scope="probe-uuid-cancel"),
        "recovered": dict(copy.deepcopy(control), scope="probe-uuid-cancel")}

class OracleTests(unittest.TestCase):
    def check(self, report, structural=None):
        structural = structural or Mock(return_value=[])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "synthesized.json"
            path.write_text(json.dumps(report))
            result = validate.validate_one(path, EXPECTED, structural)[1]
        structural.assert_called_once_with(report, generation_comparison_policy="record")
        return result

    def test_realistic_row_schemas_and_control_ids(self):
        for n in (1, 2, 4):
            for cache in (False, True):
                with self.subTest(n=n, cache=cache):
                    self.assertTrue(self.check(fixture(n, cache))["pass"])

    def test_harmony_final_overrides_analysis(self):
        self.assertEqual(validate.final_object('<|channel|>analysis<|im_sep|>{"result":0}'
            '<|channel|>final<|im_sep|>{"result":21}<|fim_suffix|>'), {"result":21})
        self.assertEqual(validate.final_object('<|meta_sep|>final<|im_sep|>{"result":21}'), {"result":21})
        self.assertIsNone(validate.final_object('<|channel|>analysis<|im_sep|>{"result":21}'))

    def test_reject_bad_json_and_duplicate_keys(self):
        for text in ('{"result":21,"result":0}', '{"result":0,"result":21}',
                     '{"result":21} trailing prose', '{"result":21'):
            self.assertIsNone(validate.final_object(text))
        self.assertEqual(validate.final_object('```json\n{"result":21}\n```'), {"result":21})

    def test_suffix_contamination_truncation_and_types_fail(self):
        for change in ({"text": json.dumps(EXPECTED["long-first"])}, {"finish": "length"},
                       {"text": '{"record":"R037","result":"21"}'},
                       {"text": '{"record":"R037","result":21.0}'}):
            report = fixture()
            row = next(r for r in report["rows"] if r["id"] == "compute-first")
            row.update(change)
            self.assertFalse(self.check(report)["pass"])

    def test_cache_counter_growth_alone_is_not_hit(self):
        for change in ({"cache_outcome":"miss"}, {"ssd_stage_disposition":"not_attempted"},
                       {"saved_tokens":0}, {"strategy":"frozenFullReplay"}, {"replay_tokens":128},
                       {"metrics_after":{"ssd_cache":{"stage_read_bytes":100}}}):
            report = fixture()
            next(r for r in report["rows"] if r["id"] == "long-repeat").update(change)
            self.assertFalse(self.check(report)["pass"])

    def test_safe_individual_batch_miss_preserved_but_all_misses_fail(self):
        report = fixture(2)
        selected = [r for r in report["rows"] if r["id"].startswith("branch-first")]
        selected[0].update(cache_outcome="miss",saved_tokens=0)
        self.assertTrue(self.check(report)["pass"])
        selected[1].update(cache_outcome="miss",saved_tokens=0)
        self.assertFalse(self.check(report)["pass"])

    def test_structural_failures_are_not_ignored(self):
        result = self.check(fixture(), Mock(return_value=[{"generated_token_accounting_inconsistent":True}]))
        self.assertFalse(result["pass"])
        self.assertIn("structural", result["errors"][0])

    def test_cache_off_need_not_construct_key_and_on_must_match(self):
        self.assertTrue(self.check(fixture(enabled=False))["pass"])
        report = fixture()
        report["metrics_loaded"]["key_mode"] = "persistent"
        self.assertFalse(self.check(report)["pass"])

    def test_repeat_prompt_mismatch_and_missing_row_fail(self):
        report = fixture()
        next(r for r in report["rows"] if r["id"] == "long-repeat")["prompt_token_ids"][-1] = 9
        self.assertFalse(self.check(report)["pass"])
        report = fixture()
        report["rows"].pop()
        self.assertFalse(self.check(report)["pass"])

if __name__ == "__main__":
    unittest.main()
