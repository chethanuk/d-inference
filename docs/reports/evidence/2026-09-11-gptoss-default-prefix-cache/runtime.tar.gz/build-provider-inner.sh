#!/bin/bash
set -euo pipefail
root=$1
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export RADIX_SOURCE_ROOT="$root/workspace"
export RADIX_CANDIDATE_BUILD=1
unset DARKBLOOM_NEMOTRON35_MTP_MODEL DARKBLOOM_LIVE_MLX_TESTS
python3 -B "$root/verify_source.py" "$root"
mkdir -p "$root/artifact"
cp -c /Users/gaj/autoresearch/gemma-qat-review-sync-20260910/artifact/mlx.metallib "$root/artifact/mlx.metallib"
cd "$root/workspace/provider-swift"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/release-build" --jobs 4 --build-tests -Xswiftc -enable-testing > "$root/logs/provider-test-build.log" 2>&1
release="$root/release-build/arm64-apple-macosx/release"
cp -c "$root/artifact/mlx.metallib" "$release/mlx.metallib"
cp -c "$root/artifact/mlx.metallib" "$release/DarkbloomProviderPackageTests.xctest/Contents/MacOS/mlx.metallib"
cp -c "$release/darkbloom" "$root/artifact/darkbloom"
for bundle in "$release/"*.bundle; do [ ! -e "$bundle" ] || cp -cR "$bundle" "$root/artifact/"; done
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter 'PrefixCache|SSDHybrid|GPTOSS|EngineV2KVBackendGate|EngineV2ProductionWiring' > "$root/logs/provider-tests.log" 2>&1
printf PASS > "$root/provider-result.txt"
cd "$root/workspace/scripts/benchmarks/radix-engine"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/benchmark-build" --jobs 4 --product radix-engine > "$root/logs/benchmark-build.log" 2>&1
release="$root/benchmark-build/arm64-apple-macosx/release"
cp -c "$root/artifact/mlx.metallib" "$release/mlx.metallib"
cp -c "$release/radix-engine" "$root/artifact/radix-engine"
for bundle in "$release/"*.bundle; do [ ! -e "$bundle" ] || cp -cR "$bundle" "$root/artifact/"; done
shasum -a 256 "$root/artifact/darkbloom" "$root/artifact/radix-engine" "$root/artifact/mlx.metallib" > "$root/artifact-sha256.txt"
python3 -B "$root/verify_source.py" "$root"
printf PASS > "$root/build-result.txt"
