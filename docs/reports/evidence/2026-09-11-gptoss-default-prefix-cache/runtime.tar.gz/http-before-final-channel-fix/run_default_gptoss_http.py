#!/usr/bin/env python3
"""Bounded isolated GPT-OSS default SSD HTTP test; execute only on the idle M5."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import threading
import tempfile
import uuid
import time
import urllib.request
from radix_prefix_cache import events, collect
from owned_process_tree import OwnedProcessTree, process_snapshot, terminate_owned

MODEL = 'gpt-oss-20b'
MODEL_HASH = '61bfc04e4016a7fa487eb10e29f79360047e302487229f298da3681984aec512'
RANKED = re.compile(r'Runner\.Worker|benchctl\s+measure-job|measure-job\.sh|(?:^|/)benchd\s+iterate|(?:^|/)bench-worker\s+(?:resident|runtime-worker)')
COMPUTE = re.compile(r'^(?:\S*/)?(?:darkbloom|radix-engine|swift-frontend|swiftc|xctest)(?:\s|$)|^(?:\S*/)?(?:xcrun\s+)?swift\s+(?:build|test)\b')
MARKERS = ('ALDER-427', 'BRONZE-913', 'CEDAR-682')


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def blockers(tree=None, rows=None):
    rows = process_snapshot() if rows is None else rows
    if tree is not None:
        tree.refresh(rows)
    result = []
    for row in rows.values():
        if row['pid'] == os.getpid() or (tree is not None and tree.owns(row)):
            continue
        if RANKED.search(row['command']) or COMPUTE.search(row['command']):
            result.append(row)
    return result


def sha256(path, check=lambda: None):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(4 << 20):
            check()
            digest.update(block)
    return digest.hexdigest()


def cases():
    common = 'The release marker is ALDER-427. The backup marker is BRONZE-913. Preserve both exactly.\n'
    common += '\n'.join(
        f'Record {n}: station {n % 17} reported a routine inspection. The reservoir gauge was checked, the inlet valve was serviced, and the next maintenance review remains proposed rather than approved.'
        for n in range(140))
    for name, question, expected, changed in [
        ('cold', 'release', 'ALDER-427', False),
        ('repeat', 'release', 'ALDER-427', False),
        ('branch', 'backup', 'BRONZE-913', False),
        ('branch-repeat', 'backup', 'BRONZE-913', False),
        ('changed-prefix', 'backup', 'CEDAR-682', True),
    ]:
        prefix = common.replace('BRONZE-913', 'CEDAR-682') if changed else common
        text = prefix + f'\nWhat is the {question} marker given at the beginning? Reply with that marker only; do not include the other marker.'
        body = {'model': MODEL, 'messages': [{'role': 'user', 'content': text}],
                'temperature': 0, 'max_tokens': 256, 'reasoning_effort': 'low',
                'stream': True, 'stream_options': {'include_usage': True}}
        yield name, expected, body


def validate_response(name, expected, result):
    if result['finish_reasons'] != ['stop']:
        raise AssertionError(f'{name}: completion must stop naturally')
    # Match the marker-only task contract; merely mentioning the right marker
    # in a negation or explanation is not a correct final answer.
    answer = re.sub(r"""^[\s`"'.*]+|[\s`"'.*]+$""", '', result['text'].upper())
    if answer != expected:
        raise AssertionError(f'{name}: incorrect final answer {result["text"]!r}')
    usage = result['usage']
    if not 4096 <= usage['prompt_tokens'] <= 8192:
        raise AssertionError(f'{name}: prompt outside bounded long-context coverage')
    # Standalone's atomic-acquire engine currently has engineV2Usage=nil and
    # does not decorate SSE usage. Missing cache detail is NOT a measured miss.
    details = usage.get('prompt_tokens_details') or {}
    cached = details.get('cached_tokens')
    if cached is not None and (type(cached) is not int or cached < 0 or cached > usage['prompt_tokens']):
        raise AssertionError(f'{name}: invalid cached token accounting')
    return cached


def legacy_artifacts(home, temp_directories):
    candidates = [home / '.darkbloom/telemetry-queue.jsonl',
                  home / '.darkbloom/telemetry-queue.jsonl.tmp',
                  home / 'Library/Caches/darkbloom/kv']
    for directory in temp_directories:
        if not directory.is_dir():
            continue
        for path in directory.iterdir():
            name = path.name
            if name.startswith('vlm-') and name.endswith('.mp4'):
                try:
                    uuid.UUID(name[4:-4])
                except ValueError:
                    continue
                candidates.append(path)
    return [str(p) for p in candidates if p.exists() or p.is_symlink()]


def default_temp_directories():
    directories = {Path(tempfile.gettempdir()), Path('/tmp')}
    if os.environ.get('TMPDIR'):
        directories.add(Path(os.environ['TMPDIR']))
    if sys.platform == 'darwin':
        result = subprocess.run(['/usr/bin/getconf', 'DARWIN_USER_TEMP_DIR'],
                                text=True, capture_output=True, check=True, timeout=5)
        if result.stdout.strip():
            directories.add(Path(result.stdout.strip()))
    return directories


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-root', type=Path, required=True)
    parser.add_argument('--model-directory', type=Path, default=Path('/Users/gaj/autoresearch/gptoss-prefix-20260911/model/gpt-oss-20b'))
    parser.add_argument('--name', required=True)
    parser.add_argument('--port', type=int, default=18142)
    parser.add_argument('--maximum-seconds', type=int, default=300)
    args = parser.parse_args()
    if args.name in ('.', '..') or Path(args.name).name != args.name:
        raise SystemExit('Name must be a single safe path component')
    if not 1 <= args.maximum_seconds <= 300:
        raise SystemExit('Runtime must be bounded to at most 300 seconds')
    active = blockers()
    if active:
        raise SystemExit('Host occupied; no hashes, links or model work performed: ' + json.dumps(active))
    root = args.build_root.resolve()
    helpers = Path(__file__).resolve().parent
    target = args.model_directory.resolve()
    output = root / 'results' / args.name
    output.parent.mkdir(exist_ok=True)
    output.mkdir(exist_ok=False)
    deadline = time.monotonic() + args.maximum_seconds
    stopped = threading.Event()
    fault = []
    lock = threading.Lock()
    owned = [None]
    ownership = [None]
    links, created = [], []
    receipt = {'started_unix': time.time(), 'status': 'starting', 'arguments': vars(args) | {'build_root': str(root), 'model_directory': str(target)},
               'links': [], 'removed_links': [], 'preserved_links': [], 'rows': [],
               'ttl': {'default_seconds': 900, 'override_absent': True, 'expiration_tested': False,
                       'scope': 'Short run records encrypted-file mtime and age; does not wait for expiration.'}}
    def check():
        if fault:
            raise RuntimeError(fault[0])
        if time.monotonic() >= deadline:
            raise RuntimeError('300-second owned run budget exceeded')
    def watch():
        while not stopped.wait(0.5):
            try:
                with lock:
                    active = blockers(ownership[0])
                reason = 'Foreign job appeared: ' + json.dumps(active) if active else 'Run deadline reached' if time.monotonic() >= deadline else None
            except Exception as exc:
                reason = 'Guard failed: ' + repr(exc)
            if reason:
                fault.append(reason)
                with lock:
                    terminate_owned(owned[0], ownership[0])
                return
    monitor = threading.Thread(target=watch, daemon=True)
    monitor.start()
    try:
        if (root / 'build-result.txt').read_text().strip() != 'PASS':
            raise RuntimeError('Exact optimized build must pass before HTTP validation')
        for relative, digest in json.loads((helpers / 'SHA256.json').read_text()).items():
            if sha256(helpers / relative, check) != digest:
                raise RuntimeError('Helper source hash mismatch: ' + relative)
        artifact = root / 'artifact'
        expected_artifacts = {}
        for line in (root / 'artifact-sha256.txt').read_text().splitlines():
            digest, name = line.split(maxsplit=1)
            path = Path(name).resolve()
            if path.parent != artifact or sha256(path, check) != digest:
                raise RuntimeError('Artifact hash or ownership mismatch')
            expected_artifacts[path.name] = digest
        if not {'darkbloom', 'mlx.metallib'} <= expected_artifacts.keys():
            raise RuntimeError('Missing verified executable or metallib')
        receipt['artifact_sha256'] = expected_artifacts
        receipt['source_proof'] = json.loads((root / 'source-proof.json').read_text())
        if sha256(root / 'source-manifest.json', check) != receipt['source_proof']['manifest_sha256']:
            raise RuntimeError('Source manifest and build proof differ')
        manifest = json.loads((helpers / 'target-manifest.json').read_text())
        if manifest['model_id'] != MODEL or manifest['aggregate_sha256'] != MODEL_HASH:
            raise RuntimeError('Wrong target manifest')
        for item in manifest['files']:
            if Path(item['path']).name != item['path']:
                raise RuntimeError('Expected flat model artifact')
            path = target / item['path']
            if path.is_symlink() or path.stat().st_size != item['size_bytes'] or sha256(path, check) != item['sha256']:
                raise RuntimeError('Target file failed verification: ' + item['path'])
        receipt['verified_model_aggregate_sha256'] = MODEL_HASH
        scanner = Path.home() / '.cache/huggingface/hub/models--gpt-oss-20b'
        if scanner.exists() or scanner.is_symlink():
            raise RuntimeError('Existing scanner namespace; preserve it and refuse')
        # Shared startup housekeeping has no override for the retired telemetry
        # queue. Refuse every exact legacy artifact before launching anything.
        legacy = legacy_artifacts(Path.home(), default_temp_directories())
        receipt['legacy_artifacts_checked_absent'] = not legacy
        if legacy:
            raise RuntimeError('Legacy shared artifacts exist; preserve them and refuse: ' + json.dumps(legacy))
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', args.port))
        snapshot = scanner / 'snapshots' / 'prefix-validation'
        missing, cursor = [], snapshot
        while not cursor.exists():
            missing.append(cursor)
            cursor = cursor.parent
        for directory in reversed(missing):
            directory.mkdir()
            created.append(directory)
        for item in manifest['files']:
            link, destination = snapshot / item['path'], target / item['path']
            link.symlink_to(destination)
            links.append((link, destination))
            receipt['links'].append(str(link))
        env = os.environ.copy()
        removed = []
        # Eliminate inherited experimental/cache overrides; preserve the real HOME.
        for key in list(env):
            if key.startswith(('DARKBLOOM_', 'MLX_', 'RADIX_')) or key in ('HF_HOME', 'HF_HUB_CACHE', 'HUGGINGFACE_HUB_CACHE', 'TRANSFORMERS_CACHE'):
                removed.append(key)
                del env[key]
        private_tmp = output / 'tmp'
        private_tmp.mkdir()
        selected = {'TMPDIR': str(private_tmp) + '/', 'DARKBLOOM_NO_UPDATE_CHECK': '1', 'DARKBLOOM_PID_FILE': str(output / 'provider.pid'),
                    'DARKBLOOM_STATE_FILE': str(output / 'state.json'), 'DARKBLOOM_WATCHDOG_STATE': str(output / 'watchdog.json'),
                    'DARKBLOOM_KV_BACKEND_GUARD': str(output / 'guard.json'), 'DARKBLOOM_LOADED_MODELS_FILE': str(output / 'loaded-models.json'),
                    'DARKBLOOM_LOCAL_DIR': str(output / 'local'), 'DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL': '1',
                    'DARKBLOOM_PREFIX_CACHE_TEST_ROOT': str(output / 'prefix-cache'), 'DARKBLOOM_PREFIX_CACHE_STATS_INTERVAL_SECS': '1'}
        env.update(selected)
        receipt.update(environment=selected, removed_inherited_environment_names=sorted(removed),
                       prefix_cache_override_absent='DARKBLOOM_PREFIX_CACHE' not in env,
                       backend_default='auto', mtp_mode_omitted=True)
        config = output / 'provider.toml'
        config.write_text(f'''config_version = 3
[backend]
enabled_models = ["{MODEL}"]
engine_v2_max_concurrent = 1
idle_timeout_mins = 60
max_model_slots = 1
port = {args.port}
preload_models = []
startup_preload = false
startup_selftest = false
startup_selftest_fail_closed = false
[coordinator]
heartbeat_interval_secs = 30
private_only = true
url = "wss://127.0.0.1:1/ws/provider"
[provider]
auto_restart = false
auto_update = false
memory_reserve_gb = 2
name = "isolated-gptoss-prefix-validation"
''')
        check()
        with (output / 'server.log').open('w') as log:
            with lock:
                owned[0] = subprocess.Popen([str(artifact / 'darkbloom'), 'start', '--local', '--config', str(config),
                                              '--model', MODEL, '--port', str(args.port), '--no-auth'], env=env,
                                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                ownership[0] = OwnedProcessTree(owned[0].pid, process_snapshot())
                receipt['owned_pgid'] = owned[0].pid
            base = f'http://127.0.0.1:{args.port}'
            def get(path):
                check()
                with urllib.request.urlopen(base + path, timeout=5) as response:
                    return response.read().decode()
            while True:
                check()
                if owned[0].poll() is not None:
                    raise RuntimeError('Owned provider exited during startup')
                try:
                    receipt['initial_health'] = get('/health')
                    break
                except OSError:
                    time.sleep(0.5)
            (output / 'metrics-before.txt').write_text(get('/metrics'))
            for name, marker, body in cases():
                check()
                write_json(output / (name + '-request.json'), body)
                started, raw = time.perf_counter(), []
                request = urllib.request.Request(base + '/v1/chat/completions', data=json.dumps(body).encode(),
                                                 headers={'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(request, timeout=90) as response:
                        if response.status != 200 or 'text/event-stream' not in response.headers.get('Content-Type', ''):
                            raise RuntimeError('Expected HTTP 200 event stream')
                        def captured():
                            for payload in events(response):
                                check()
                                raw.append({'elapsed_s': time.perf_counter() - started, 'data': payload})
                                yield payload
                        result = collect(captured(), started)
                finally:
                    write_json(output / (name + '-raw-sse.json'), raw)
                write_json(output / (name + '-response.json'), result)
                cached = validate_response(name, marker, result)
                receipt['rows'].append({'name': name, 'cached_tokens': cached, 'ttft_s': result['ttft_s'],
                                        'cache_usage_reported': cached is not None,
                                        'elapsed_s': result['elapsed_s'], 'final_answer': result['text']})
                # Allow the asynchronous donation to complete before the next request.
                settle = time.monotonic() + 2
                while time.monotonic() < settle:
                    check()
                    time.sleep(0.1)
                metric = get('/metrics')
                (output / (name + '-metrics.txt')).write_text(metric)
                observation = [{'path': str(p.relative_to(output)), 'size': p.stat().st_size,
                                'mtime_unix': p.stat().st_mtime, 'age_seconds': time.time() - p.stat().st_mtime}
                               for p in (output / 'prefix-cache').rglob('*.dbk3')]
                write_json(output / (name + '-cache-files.json'), observation)
                if not observation:
                    raise RuntimeError('Expected encrypted complete-checkpoint files in the owned root')
            final_metrics = get('/metrics')
            if not re.search(r'^mtp_active\{model="gpt-oss-20b"\} 0$', final_metrics, re.M):
                raise RuntimeError('Expected actual GPT-OSS MTP-inactive posture from /metrics')
            log.flush()
            server_text = (output / 'server.log').read_text()
            cache_line = next((line for line in server_text.splitlines() if
                'gpt-oss-20b prefix cache on (memory=off, ssd=on: encrypted complete checkpoints' in line), None)
            receipt['cache_activation_log'] = cache_line
            receipt['backend_observation'] = {
                'resolved': 'paged' if cache_line else None,
                'evidence_kind': 'inferred_from_loaded_historical_complete_cache_gate' if cache_line else 'not_exposed',
                'limitation': 'Local /metrics has no KV-backend metric. OS-log activation may not appear in redirected stdout/stderr. Native live tests assert the resolved backend directly.'}
            receipt['cache_hit_proof'] = {
                'provided_by_this_run': False,
                'reason': 'Standalone currently omits cache details from SSE; native and radix tests prove restoration directly.'}
            receipt['scope'] = 'Default HTTP serving, task semantics, actual MTP posture and encrypted persistence; not a hit or timing-speedup gate.'
            check()
            receipt['status'] = 'passed'
            return 0
    except BaseException as exc:
        receipt.update(status='failed', failure=repr(exc))
        raise
    finally:
        stopped.set()
        monitor.join(timeout=5)
        cleanup_errors = []
        try:
            with lock:
                terminate_owned(owned[0], ownership[0])
        except Exception as exc:
            cleanup_errors.append(repr(exc))
        for link, destination in links:
            if link.is_symlink() and os.readlink(link) == str(destination):
                link.unlink()
                receipt['removed_links'].append(str(link))
            elif link.exists() or link.is_symlink():
                receipt['preserved_links'].append(str(link))
        for directory in reversed(created):
            try:
                directory.rmdir()
            except OSError:
                pass
        receipt.update(ended_unix=time.time(), guard_faults=fault, cleanup_errors=cleanup_errors,
                       owned_process_identities=ownership[0].receipt() if ownership[0] else [])
        if cleanup_errors or fault:
            receipt['status'] = 'failed'
        write_json(output / 'report.json', receipt)
        print(json.dumps({'status': receipt['status'], 'output': str(output)}))
        if cleanup_errors or fault:
            raise RuntimeError('Owned cleanup or guard failed; inspect receipt')


if __name__ == '__main__':
    for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        signal.signal(sig, lambda signum, frame: sys.exit(128 + signum))
    raise SystemExit(main())
