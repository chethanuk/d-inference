import signal
import unittest
from owned_process_tree import OwnedProcessTree, terminate_owned
from run_default_gptoss_http import blockers


def row(pid, parent, group, command='/build/artifact/darkbloom runtime-smoke 64:8:64:1:1', started='Fri Sep 11 01:00:00 2026'):
    return {'pid': pid, 'ppid': parent, 'pgid': group, 'started': started, 'command': command}


class FakeProcess:
    pid = 100
    def poll(self): return None
    def wait(self, timeout): return 0


class OwnedTreeTests(unittest.TestCase):
    def test_separate_group_smoke_and_grandchildren_are_owned(self):
        rows = {100: row(100, 50, 100, '/build/artifact/darkbloom start --local')}
        tree = OwnedProcessTree(100, rows)
        rows.update({200: row(200, 100, 200), 201: row(201, 200, 201)})
        self.assertEqual(blockers(tree, rows), [])
        self.assertEqual({r['pid'] for r in tree.receipt()}, {100, 200, 201})
        # Parent exit/reparenting cannot erase already observed ownership.
        del rows[100]
        rows[200]['ppid'] = 1
        self.assertEqual(blockers(tree, rows), [])

    def test_identical_foreign_binary_and_ranked_jobs_remain_blockers(self):
        rows = {100: row(100, 50, 100), 300: row(300, 1, 300),
                301: row(301, 1, 301, '/runner/Runner.Worker spawnclient')}
        tree = OwnedProcessTree(100, rows)
        self.assertEqual({r['pid'] for r in blockers(tree, rows)}, {300, 301})

    def test_reused_child_pid_cannot_inherit_ownership(self):
        rows = {100: row(100, 50, 100), 200: row(200, 100, 200)}
        tree = OwnedProcessTree(100, rows)
        rows[200] = row(200, 1, 200, started='Fri Sep 11 01:01:00 2026')
        self.assertEqual([r['pid'] for r in blockers(tree, rows)], [200])

    def test_cleanup_signals_only_owned_groups_child_first(self):
        rows = {100: row(100, 50, 100), 200: row(200, 100, 200), 300: row(300, 1, 300)}
        tree = OwnedProcessTree(100, rows)
        calls = []
        def kill(group, sig):
            calls.append((group, sig))
            for pid in [pid for pid, value in rows.items() if value['pgid'] == group]:
                del rows[pid]
        terminate_owned(FakeProcess(), tree, snapshot=lambda: dict(rows), killpg=kill)
        self.assertEqual(calls, [(200, signal.SIGTERM), (100, signal.SIGTERM)])
        self.assertIn(300, rows)

    def test_eperm_suppressed_only_for_fresh_empty_group(self):
        rows = {100: row(100, 50, 100)}
        tree = OwnedProcessTree(100, rows)
        def disappeared(group, sig):
            rows.clear()
            raise PermissionError('Darwin empty-group race')
        terminate_owned(FakeProcess(), tree, snapshot=lambda: dict(rows), killpg=disappeared)
        rows[100] = row(100, 50, 100)
        def still_present(group, sig): raise PermissionError('Still present')
        with self.assertRaises(PermissionError):
            terminate_owned(FakeProcess(), tree, snapshot=lambda: dict(rows), killpg=still_present)

    def test_unowned_member_prevents_group_signal(self):
        rows = {100: row(100, 50, 100), 200: row(200, 100, 200), 300: row(300, 1, 200)}
        tree = OwnedProcessTree(100, rows)
        calls = []
        with self.assertRaises(RuntimeError):
            terminate_owned(FakeProcess(), tree, snapshot=lambda: dict(rows),
                            killpg=lambda group, sig: calls.append((group, sig)))
        self.assertEqual(calls, [])

if __name__ == '__main__': unittest.main()
