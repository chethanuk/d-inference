import unittest
import tempfile
from pathlib import Path
from run_default_gptoss_http import cases, validate_response, legacy_artifacts, RANKED, COMPUTE
from radix_prefix_cache import collect

class HTTPHelperTests(unittest.TestCase):
    def result(self, marker='BRONZE-913', cached=4096):
        return {'text': marker, 'finish_reasons': ['stop'],
                'usage': {'prompt_tokens': 6000, 'prompt_tokens_details': {'cached_tokens': cached}}}

    def test_semantics_and_usage_validation(self):
        self.assertEqual(validate_response('repeat', 'BRONZE-913', self.result()), 4096)
        for result in [self.result('ALDER-427'), self.result('BRONZE-913 CEDAR-682'), self.result(cached=-1)]:
            with self.assertRaises(AssertionError):
                validate_response('repeat', 'BRONZE-913', result)
        result = self.result()
        result['finish_reasons'] = ['length']
        with self.assertRaises(AssertionError):
            validate_response('repeat', 'BRONZE-913', result)

    def test_marker_only_answer_rejects_negation_and_explanation(self):
        for answer in ('Not BRONZE-913', 'The marker is BRONZE-913',
                       'BRONZE-913 is incorrect', 'Do not answer BRONZE-913'):
            with self.assertRaises(AssertionError):
                validate_response('repeat', 'BRONZE-913', self.result(answer))
        for answer in ('BRONZE-913', '  **BRONZE-913**.\n', '`bronze-913`', '\"BRONZE-913\"', '\u00a0** BRONZE-913 **\u00a0'):
            self.assertEqual(validate_response('repeat', 'BRONZE-913', self.result(answer)), 4096)

    def test_missing_cache_usage_is_unreported_not_zero(self):
        result = self.result()
        del result['usage']['prompt_tokens_details']
        self.assertIsNone(validate_response('repeat', 'BRONZE-913', result))
        self.assertEqual(validate_response('repeat', 'BRONZE-913', self.result(cached=0)), 0)

    def test_legacy_artifacts_refused_without_removing_them(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            home, video = root / 'home', root / 'video'
            (home / '.darkbloom').mkdir(parents=True)
            video.mkdir()
            queue = home / '.darkbloom/telemetry-queue.jsonl'
            media = video / 'vlm-00000000-0000-4000-8000-000000000001.mp4'
            unrelated = video / 'vlm-unrelated.mp4'
            for path in (queue, media, unrelated):
                path.write_text('fixture')
            found = legacy_artifacts(home, {video})
            self.assertCountEqual(found, [str(queue), str(media)])
            self.assertTrue(all(p.exists() for p in (queue, media, unrelated)))

    def test_prefix_changes_and_repeats(self):
        rows = list(cases())
        self.assertEqual(len(rows), 5)
        self.assertEqual(rows[0][2], rows[1][2])
        self.assertEqual(rows[2][2], rows[3][2])
        donor = rows[0][2]['messages'][0]['content']
        branch = rows[2][2]['messages'][0]['content']
        self.assertEqual(donor.rsplit('\n', 1)[0], branch.rsplit('\n', 1)[0])
        self.assertIn('CEDAR-682', rows[4][2]['messages'][0]['content'][:150])

    def test_incomplete_sse_is_rejected(self):
        with self.assertRaises(RuntimeError):
            collect(['{"choices":[{"index":0,"delta":{"content":"BRONZE-913"}}]}'], 0, clock=lambda: 1)

    def test_foreign_job_patterns(self):
        for command in ['/ci/Runner.Worker spawnclient', '/usr/bin/benchctl measure-job job',
                        '/run/measure-job.sh', '/run/benchd iterate', '/run/bench-worker runtime-worker']:
            self.assertTrue(RANKED.search(command))
        for command in ['/usr/bin/swift-frontend -c a.swift', '/run/artifact/darkbloom start',
                        '/run/artifact/radix-engine --input input.json', '/usr/bin/xcrun swift build']:
            self.assertTrue(COMPUTE.search(command))
        self.assertFalse(COMPUTE.search('python3 /tmp/http/run_default_gptoss_http.py --build-root /tmp/build'))

if __name__ == '__main__':
    unittest.main()
