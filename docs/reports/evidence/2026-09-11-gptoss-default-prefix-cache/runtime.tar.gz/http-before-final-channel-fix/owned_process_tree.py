"""Track descendants of one verified provider, including setsid smoke children."""
import os
import signal
import subprocess


def process_snapshot():
    result = {}
    output = subprocess.check_output(
        ['/bin/ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command='], text=True)
    for row in output.splitlines():
        fields = row.strip().split(None, 8)
        if len(fields) != 9:
            continue
        pid, parent, group = map(int, fields[:3])
        result[pid] = {'pid': pid, 'ppid': parent, 'pgid': group,
                       'started': ' '.join(fields[3:8]), 'command': fields[8]}
    return result


def identity(row):
    return row['pid'], row['started']


class OwnedProcessTree:
    def __init__(self, root_pid, initial_snapshot):
        root = initial_snapshot.get(root_pid)
        if root is None:
            raise RuntimeError('Owned provider exited before its process identity could be captured')
        self.root_pid = root_pid
        self.records = {identity(root): dict(root, ownership='launched_by_helper')}
        self.refresh(initial_snapshot)

    def refresh(self, rows):
        # Only a currently observed, identity-matching parent can authorize a
        # new descendant. A reused PID or merely identical executable cannot.
        owned_pids = {pid for pid, row in rows.items() if identity(row) in self.records}
        changed = True
        while changed:
            changed = False
            for pid, row in rows.items():
                if pid in owned_pids or row['ppid'] not in owned_pids:
                    continue
                self.records[identity(row)] = dict(row, ownership='observed_descendant',
                                                   owner_parent_started=rows[row['ppid']]['started'])
                owned_pids.add(pid)
                changed = True
        return {pid: row for pid, row in rows.items() if identity(row) in self.records}

    def owns(self, row):
        return identity(row) in self.records

    def receipt(self):
        return list(self.records.values())


def terminate_owned(process, tree, snapshot=process_snapshot, killpg=os.killpg):
    if process is None:
        return
    if tree is None:
        # No descendant identity was captured: the Popen parent is still our
        # child and can be signalled individually without guessing a group.
        process.terminate()
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        return
    for sig in (signal.SIGTERM, signal.SIGKILL):
        # poll()/wait() reap the direct child before Darwin's second group
        # signal. An unreaped exited group leader can otherwise cause EPERM.
        process.poll()
        rows = snapshot()
        owned = tree.refresh(rows)
        groups = {row['pgid'] for row in owned.values()}
        # Retire separate smoke/caffeinate groups first, then their provider.
        for group in sorted(groups, key=lambda value: value == process.pid):
            rows = snapshot()
            tree.refresh(rows)
            members = [row for row in rows.values() if row['pgid'] == group]
            if not members:
                continue
            if any(not tree.owns(row) for row in members):
                raise RuntimeError(f'Refusing group {group}: it contains an unowned process identity')
            try:
                killpg(group, sig)
            except ProcessLookupError:
                continue
            except PermissionError:
                process.poll()
                if any(row['pgid'] == group for row in snapshot().values()):
                    raise
                # Suppress EPERM only after a fresh snapshot proves emptiness.
        if sig == signal.SIGTERM:
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
    process.wait(timeout=5)
    remaining = tree.refresh(snapshot())
    if remaining:
        raise RuntimeError('Owned descendants remain after cleanup: ' + repr(list(remaining.values())))
