from pathlib import Path
import hashlib,json,shutil
root=Path('/Users/gaj/autoresearch/gptoss-prefix-20260911')
archive=root/'revision2-build';archive.mkdir(exist_ok=False)
for name in ['source-manifest.json','source-proof.json','artifact-sha256.txt','build-result.txt','provider-result.txt']:
 p=root/name
 if p.exists():shutil.copy2(p,archive/name)
manifest=json.loads((root/'source-manifest.json').read_text())
files=['provider-swift/Tests/ProviderCoreTests/GPTOSSCheckpointRestartFixture.swift','provider-swift/Tests/ProviderCoreTests/GPTOSSMixedPrefixCacheLiveTests.swift','provider-swift/Tests/ProviderCoreTests/GPTOSSMixedPrefixCohort.swift']
for rel in files:
 destination=root/'workspace'/rel
 if destination.exists():shutil.copy2(destination,archive/destination.name)
 shutil.copy2(root/'mixed-source'/destination.name,destination)
 entry={'path':rel,'sha256':hashlib.sha256(destination.read_bytes()).hexdigest()}
 existing=next((v for v in manifest['files'] if v['path']==rel),None)
 if existing:existing.update(entry)
 else:manifest['files'].append(entry)
manifest['source_amendment']={'commit':'d22ad0cf3','changed_files':files,'production_source_unchanged':True,'previous_manifest':'revision2-build/source-manifest.json'}
(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'build-result.txt').unlink(missing_ok=True)
