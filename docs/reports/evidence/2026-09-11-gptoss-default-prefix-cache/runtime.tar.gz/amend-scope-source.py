from pathlib import Path
import hashlib,json,shutil
root=Path('/Users/gaj/autoresearch/gptoss-prefix-20260911')
archive=root/'revision3-build';archive.mkdir(exist_ok=False)
for name in ['source-manifest.json','source-proof.json','artifact-sha256.txt','build-result.txt','provider-result.txt']:
 p=root/name
 if p.exists():shutil.copy2(p,archive/name)
rel='provider-swift/Tests/ProviderCoreTests/GPTOSSMixedPrefixCacheLiveTests.swift'
dest=root/'workspace'/rel
shutil.copy2(dest,archive/dest.name)
shutil.copy2(root/'scope-source'/dest.name,dest)
manifest=json.loads((root/'source-manifest.json').read_text())
next(v for v in manifest['files'] if v['path']==rel)['sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
manifest['source_amendment']={'commit':'49b62bfe6','changed_files':[rel],'production_source_unchanged':True,'previous_manifest':'revision3-build/source-manifest.json'}
(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'build-result.txt').unlink(missing_ok=True)
