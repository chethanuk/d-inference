#!/usr/bin/env python3
"""Guard an owned fresh provider build; never signal ranked or unrelated jobs."""
import argparse, json, os, re, signal, subprocess, sys, time
from pathlib import Path

RANKED = re.compile(r'Runner\.Worker|benchctl\s+measure-job|measure-job\.sh|(?:^|/)benchd\s+iterate|(?:^|/)bench-worker\s+(?:resident|runtime-worker)')

def blockers(owned_group=None):
    rows = subprocess.check_output(['/bin/ps', '-axo', 'pid=,pgid=,command='], text=True)
    result=[]
    for line in rows.splitlines():
        parts=line.strip().split(None,2)
        if len(parts)!=3: continue
        pid, pgid, command=int(parts[0]),int(parts[1]),parts[2]
        if pid==os.getpid() or pgid==owned_group: continue
        if RANKED.search(command): result.append({'pid':pid,'pgid':pgid,'command':command})
    return result

def owned_group_members(pgid):
    rows = subprocess.check_output(['/bin/ps', '-axo', 'pid=,pgid='], text=True)
    members = []
    for line in rows.splitlines():
        pid, group = map(int, line.split())
        if group == pgid: members.append(pid)
    return members

def terminate_owned(proc):
    # Child was launched with start_new_session: only that child's group is owned.
    for sig in [signal.SIGTERM,signal.SIGKILL]:
        if sig == signal.SIGKILL and not owned_group_members(proc.pid): break
        try: os.killpg(proc.pid,sig)
        except ProcessLookupError: break
        except PermissionError:
            # Darwin can report EPERM after TERM has emptied the group.
            # Suppress only when a fresh process snapshot confirms that case.
            if owned_group_members(proc.pid): raise
            break
        if sig==signal.SIGTERM: time.sleep(2)
    try: proc.wait(timeout=10)
    except subprocess.TimeoutExpired: raise RuntimeError('Owned group did not terminate after SIGKILL')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--maximum-seconds',type=int,default=2400);parser.add_argument('--check',action='store_true');args=parser.parse_args()
    if args.check:
        active=blockers(os.getpgrp())
        if active: print(json.dumps({'refused_ranked_jobs':active}))
        return 75 if active else 0
    root=args.root.resolve();root.mkdir(parents=True,exist_ok=True)
    # Refuse accidental reruns or reuse of any build tree. Keep aborted roots intact.
    if (root/'guard-status.json').exists() or (root/'release-build').exists():
        raise SystemExit('Existing status/scratch: preserve evidence and use a new owned run root')
    status={'status':'starting','started_unix':time.time(),'root':str(root)};proc=None;interrupted=[]
    def handle(sig,frame): interrupted.append(sig)
    for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,handle)
    try:
        active=blockers()
        if active:
            status.update(status='refused',reason='ranked job already present',ranked_jobs=active);return 75
        (root/'logs').mkdir(exist_ok=True)
        with (root/'logs/guarded-build.log').open('w') as log:
            proc=subprocess.Popen(['/bin/bash',str(root/'build-provider-inner.sh'),str(root)],start_new_session=True,stdout=log,stderr=subprocess.STDOUT)
            status['owned_pgid']=proc.pid
            deadline=time.monotonic()+args.maximum_seconds
            while proc.poll() is None:
                active=blockers(proc.pid)
                reason='ranked job appeared' if active else 'interrupted by owner' if interrupted else 'build time bound reached' if time.monotonic()>=deadline else None
                if reason:
                    status.update(status='aborted',reason=reason,ranked_jobs=active)
                    terminate_owned(proc);return 75
                time.sleep(1)
            status.update(status='passed' if proc.returncode==0 else 'failed',process_exit_code=proc.returncode)
            return proc.returncode
    except BaseException as exc:
        status.update(status='failed',error=repr(exc))
        if proc is not None and proc.poll() is None:terminate_owned(proc)
        raise
    finally:
        status['ended_unix']=time.time();(root/'guard-status.json').write_text(json.dumps(status,indent=2)+'\n')

if __name__=='__main__':sys.exit(main())
