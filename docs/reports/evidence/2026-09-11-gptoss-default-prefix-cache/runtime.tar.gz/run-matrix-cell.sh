#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gptoss-prefix-20260911
width=$1
cache=$2
name=$3
unset MLX_ENABLE_TF32
python3 -B "$root/workspace/scripts/benchmarks/run_radix_engine.py" \
 --binary "$root/artifact/radix-engine" --model-directory "$root/model/gpt-oss-20b" \
 --input "$root/validation/input.json" --output "$root/results/$name" \
 --cache "$cache" --mtp off --kv-backend paged --cache-mode ssd --key-mode ephemeral \
 --production-kv-grant --expected-model-sha256 61bfc04e4016a7fa487eb10e29f79360047e302487229f298da3681984aec512 \
 --prompt-date 2026-09-11 --concurrency "$width" --generation-comparison-policy record
