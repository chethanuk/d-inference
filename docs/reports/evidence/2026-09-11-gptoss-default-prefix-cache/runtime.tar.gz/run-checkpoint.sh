#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gptoss-prefix-20260911
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
unset MLX_ENABLE_TF32
export DARKBLOOM_LIVE_MLX_TESTS=1 DARKBLOOM_LIVE_MLX_GPTOSS_CHECKPOINT_RESTART=1
export DARKBLOOM_LIVE_MLX_GPTOSS_MODEL_DIRECTORY="$root/model/gpt-oss-20b"
cd "$root/workspace/provider-swift"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter GPTOSSCheckpointRestartLiveTests
