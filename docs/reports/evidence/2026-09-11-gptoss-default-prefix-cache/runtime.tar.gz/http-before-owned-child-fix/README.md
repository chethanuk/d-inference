# GPT-OSS default SSD HTTP fixture — prepared, not executed

After the owned optimized build finishes successfully and the M5 is idle, copy
this entire directory into that build root as `http`, then run:

```sh
python3 -B /Users/gaj/autoresearch/gptoss-prefix-20260911/http/run_default_gptoss_http.py \
  --build-root /Users/gaj/autoresearch/gptoss-prefix-20260911 \
  --model-directory /Users/gaj/autoresearch/gptoss-prefix-20260911/model/gpt-oss-20b \
  --name http-default-cache-1
```

The helper refuses an occupied host, failed build, mismatched executable or
metallib, mismatched source-proof manifest, mismatched target file sizes/hashes,
existing scanner namespace, existing output, or legacy shared cache, telemetry queue, or UUID-named video files. Verification
and serving share a 300-second budget, followed by bounded owned-process cleanup.
A 500ms watchdog terminates only this helper's provider process group if another
ranked/Swift/model job appears. Target hashing checks that guard every 4MiB.

Only missing scanner directories and ten links to the verified target artifact
are created under the exact `models--gpt-oss-20b` namespace. Cleanup removes only
unchanged owned links and empty owned directories. Provider PID, state, watchdog,
backend-guard, loaded-model list, local discovery, and ephemeral SSD cache paths
and TMPDIR all live under the new results directory. The encrypted cache is retained there;
there is no shared-cache cleanup or installation/deployment.

The child has no `DARKBLOOM_PREFIX_CACHE` override, no resident-cache override, no
TTL override, no backend override, no MTP override, and no assistant override.
Inherited DARKBLOOM/MLX/RADIX/HF experimental variables are removed by name without
recording their values. This intentionally tests shipped default behavior with
test-owned persistence/key material.

Five B1 requests exercise cold, repeat, branched suffix, branch repeat, and an
altered early fact. Long prompts are checked from actual usage to fall between
4096 and 8192 tokens. Every response must finish naturally with HTTP 200, SSE
DONE and usage, and its final answer must contain the correct marker without a
stale donor/changed marker. Standalone currently does not expose cached tokens in SSE usage: its atomic-acquire engine initializes engineV2Usage to nil. Missing detail is recorded as null/unreported, never a measured miss. This helper does not assert reuse from HTTP; native and radix tests supply direct hit evidence.

Raw SSE frames, full requests/responses, per-request TTFT, metrics, server logs,
encrypted-file metadata, artifact and source bindings, and scanner cleanup are
retained. MTP inactivity is asserted from the actual `/metrics` posture. The
loaded production log, when present in redirected output, records encrypted complete checkpoints and no resident cache. The provider uses OS logging, so this log is optional; encrypted files in the fresh owned root remain required persistence evidence. There is no local KV-backend Prometheus metric, so the report explicitly
labels paged as inferred from the loaded GPT-OSS historical-cache gate only when its activation line was observed. Otherwise the backend observation is null/not_exposed, not a guessed actual backend. Live native tests provide direct backend assertions.

This fixture does not establish HTTP cache hits or speedup, broad answer quality, B2/B4 safety, exact token
parity, keychain recovery, cross-process warm cache, or TTL expiration. Default
TTL remains 900 seconds; file ages and access survival are observations only.
Cold TTFT includes model loading; warm TTFT is an HTTP observation, not an
isolated prefill benchmark. The helper's six CPU tests passed locally; no
real-model execution has been performed by its author.
