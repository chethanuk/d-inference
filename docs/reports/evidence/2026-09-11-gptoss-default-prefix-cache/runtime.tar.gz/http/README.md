# GPT-OSS default SSD HTTP fixture — prepared, not executed

After the owned optimized build finishes successfully and the M5 is idle, copy
this entire directory into that build root as `http`, then run:

```sh
python3 -B /Users/gaj/autoresearch/gptoss-prefix-20260911/http/run_default_gptoss_http.py \
  --build-root /Users/gaj/autoresearch/gptoss-prefix-20260911 \
  --model-directory /Users/gaj/autoresearch/gptoss-prefix-20260911/model/gpt-oss-20b \
  --name http-default-cache-1
```

The helper refuses an occupied host, failed build, mismatched executable or
metallib, mismatched source-proof manifest, mismatched target file sizes/hashes,
existing scanner namespace, existing output, or legacy shared cache, telemetry queue, or UUID-named video files. Verification
and serving share a 300-second budget, followed by bounded owned-process cleanup.
A 500ms watchdog terminates only this helper's provider and observed descendant process groups if another
ranked/Swift/model job appears. Target hashing checks that guard every 4MiB.

Only missing scanner directories and ten links to the verified target artifact
are created under the exact `models--gpt-oss-20b` namespace. Cleanup removes only
unchanged owned links and empty owned directories. Provider PID, state, watchdog,
backend-guard, loaded-model list, local discovery, and ephemeral SSD cache paths
and TMPDIR all live under the new results directory. The encrypted cache is retained there;
there is no shared-cache cleanup or installation/deployment.

The child has no `DARKBLOOM_PREFIX_CACHE` override, no resident-cache override, no
TTL override, no backend override, no MTP override, and no assistant override.
Inherited DARKBLOOM/MLX/RADIX/HF experimental variables are removed by name without
recording their values. This intentionally tests shipped default behavior with
test-owned persistence/key material.

Five B1 requests exercise cold, repeat, branched suffix, branch repeat, and an
altered early fact. Long prompts are checked from actual usage to fall between
4096 and 8192 tokens. Every response must finish naturally with HTTP 200, SSE
DONE and usage, and its normalized final answer must equal the requested marker exactly (case and surrounding whitespace/Markdown quotes or punctuation may differ). A negation or explanation that merely contains the marker fails. Standalone currently does not expose cached tokens in SSE usage: its atomic-acquire engine initializes engineV2Usage to nil. Missing detail is recorded as null/unreported, never a measured miss. This helper does not assert reuse from HTTP; native and radix tests supply direct hit evidence.

Raw SSE frames, full requests/responses, per-request TTFT, metrics, server logs,
encrypted-file metadata, artifact and source bindings, and scanner cleanup are
retained. MTP inactivity is asserted from the actual `/metrics` posture. The
loaded production log, when present in redirected output, records encrypted complete checkpoints and no resident cache. The provider uses OS logging, so this log is optional; encrypted files in the fresh owned root remain required persistence evidence. There is no local KV-backend Prometheus metric, so the report explicitly
labels paged as inferred from the loaded GPT-OSS historical-cache gate only when its activation line was observed. Otherwise the backend observation is null/not_exposed, not a guessed actual backend. Live native tests provide direct backend assertions.

This fixture does not establish HTTP cache hits or speedup, broad answer quality, B2/B4 safety, exact token
parity, keychain recovery, cross-process warm cache, or TTL expiration. Default
TTL remains 900 seconds; file ages and access survival are observations only.
Cold TTFT includes model loading; warm TTFT is an HTTP observation, not an
isolated prefill benchmark. The helper's sixteen CPU tests passed locally; no
real-model execution has been performed by its author.


Ownership follows observed PID/PPID ancestry, bound to each PID's start time.
The provider's normal `PagedKernelPreflight` launches its own verified executable
with `runtime-smoke` through `BoundedProcess`; that child may enter a separate
process group. It and observed descendants are owned, while an identical
executable launched by another root remains a blocker. Ownership survives
observed-child reparenting but never PID reuse. Cleanup refuses to signal any
group containing an unowned identity, retires child groups before the provider,
and reaps the direct child before the second Darwin group signal. EPERM is
suppressed only when a fresh process snapshot proves the group is empty.
The report retains observed ancestry/start-time receipts.


The existing standalone transport can place raw Harmony analysis/final framing
in the content delta. The HTTP oracle now extracts only the last canonical
`<|channel|>final<|message|>` segment (ending at the first Harmony terminator)
before exact normalized marker comparison. Analysis-only, malformed framing,
wrong final answers and negated/explanatory answers fail even if analysis cites
the right marker. Raw SSE/response text is preserved verbatim; parsed final
content is recorded separately in `*-parsed-answer.json` and report rows. The
report explicitly records raw Harmony transport as an existing limitation,
not a fixed presentation issue or a passing transport-format claim.
