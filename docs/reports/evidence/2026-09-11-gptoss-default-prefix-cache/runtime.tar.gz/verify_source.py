from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);manifest=json.loads((root/'source-manifest.json').read_text());workspace=root/'workspace'
for entry in manifest['files']:
 p=workspace/entry['path']
 if 'symlink' in entry:assert p.is_symlink() and str(p.readlink())==entry['symlink'],entry['path']
 else:assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],entry['path']
metal=Path('/Users/gaj/autoresearch/gemma-qat-review-sync-20260910/artifact/mlx.metallib')
assert hashlib.sha256(metal.read_bytes()).hexdigest()=='20972c37e53fe6db3b3191a0434f6604c4ffc4f5ac62b370574f9922585b0fdb'
proof={'base_head':manifest['base_head'],'pins':manifest['pins'],'manifest_sha256':hashlib.sha256((root/'source-manifest.json').read_bytes()).hexdigest(),'verified_files':len(manifest['files']),'metallib_sha256':'20972c37e53fe6db3b3191a0434f6604c4ffc4f5ac62b370574f9922585b0fdb'}
(root/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
