#!/usr/bin/env python3
"""Independent answer oracle plus existing structural evidence checks; no model execution."""
import argparse
import hashlib
import json
import math
import re
import statistics
import sys
from pathlib import Path

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def final_object(text):
    # Native reports retain Harmony text; never accept an analysis-channel JSON
    # when an explicit final channel is present. Otherwise take the final JSON
    # value with no trailing prose, allowing normal fenced JSON presentation.
    matches = list(re.finditer(
        r"(?:<\|(?:meta_sep|channel)\|>\s*final\s*"
        r"(?:<\|constrain\|>\s*json\s*)?(?:<\|(?:im_sep|message)\|>)?|\bfinal<\|im_sep\|>)", text))
    if matches:
        text = text[matches[-1].end():]
    elif re.search(r"<\|(?:meta_sep|channel)\|>\s*analysis\b", text):
        return None
    # GPT-OSS's canonical decoded completion terminator is <|return|>.
    # Strip framing only at the end, never inside JSON strings or before
    # trailing prose; the latter must remain an invalid final answer.
    text = re.sub(r"(?:\s*<\|(?:im_end|fim_suffix|endoftext|return|end)\|>)+\s*$", "", text).strip()
    text = re.sub(r"```(?:json)?", "", text).strip()
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    decoder = json.JSONDecoder(object_pairs_hook=unique_object)
    candidates = []
    for match in re.finditer(r"\{", text):
        try:
            value, end = decoder.raw_decode(text[match.start():])
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(value, dict) and not text[match.start() + end:].strip():
            candidates.append(value)
    return candidates[-1] if candidates else None

def hit(row):
    before = row.get("metrics_before", {}).get("ssd_cache", {}).get("stage_read_bytes")
    after = row.get("metrics_after", {}).get("ssd_cache", {}).get("stage_read_bytes")
    return (row.get("cache_outcome") == "hit" and row.get("ssd_stage_disposition") == "staged"
            and type(row.get("saved_tokens")) is int and row["saved_tokens"] > 0
            and row.get("replay_tokens") == 0 and row.get("strategy") == "direct"
            and type(row.get("matched_tokens")) is int and row["matched_tokens"] > 0
            and type(before) is int and type(after) is int and 0 <= before < after)

def distribution(values):
    values = sorted(v for v in values if type(v) in (int, float) and math.isfinite(v))
    if not values:
        return {"n": 0}
    return {"n": len(values), "min": min(values), "median": statistics.median(values),
            "p95_nearest_rank": values[math.ceil(len(values) * .95) - 1], "max": max(values)}

def base_id(value):
    return re.sub(r"-b[0-3]$", "", value)

def validate_one(path, expected, structural):
    report = load(path)
    errors = [{"structural": e} for e in structural(report, generation_comparison_policy="record")]
    rows = report.get("rows", [])
    concurrency = report.get("max_concurrent_requests")
    if concurrency not in (1, 2, 4):
        errors.append({"invalid_concurrency": concurrency})
    planned = {key + (f"-b{i}" if concurrency != 1 else "")
               for key in expected for i in range(concurrency if concurrency in (1, 2, 4) else 0)}
    if len(rows) != len(planned) or {r.get("id") for r in rows} != planned:
        errors.append({"missing_or_duplicate_rows": True})
    if report.get("model") != "gpt-oss-20b" or report.get("resolved_backend") != "paged":
        errors.append({"wrong_model_or_backend": True})
    if not str(report.get("mtp", "")).startswith("off"):
        errors.append({"mtp_was_not_disabled": True})
    requested_key = report.get("key_mode_requested")
    if requested_key not in ("ephemeral", "persistent"):
        errors.append({"missing_requested_key_mode": True})
    elif report.get("cache_requested") and report.get("metrics_loaded", {}).get("key_mode") != requested_key:
        errors.append({"cache_key_mode_mismatch": True})
    semantic = []
    controls = report.get("tenant_checks", []) + [report.get("cancel_donor", {}), report.get("recovered", {})]
    for row in rows + controls:
        key = base_id(row.get("id", ""))
        wanted = expected.get(key)
        observed = final_object(row.get("text", ""))
        valid = (wanted is not None and observed == wanted
                 and all(type(observed[k]) is type(v) for k, v in wanted.items()))
        semantic.append({"id": row.get("id"), "scope": row.get("scope"),
                         "expected": wanted, "observed": observed, "pass": valid})
        if not valid:
            errors.append({"id": row.get("id"), "semantic_mismatch": True})
        if row.get("finish") != "stop":
            errors.append({"id": row.get("id"), "answer_did_not_naturally_finish": row.get("finish")})
        if row.get("prompt_render_date") != "2026-09-11":
            errors.append({"id": row.get("id"), "wrong_request_date": True})
        if row.get("sampling", {}).get("temperature") != 0:
            errors.append({"id": row.get("id"), "not_greedy": True})
    for name in expected:
        selected = [r for r in rows if base_id(r.get("id", "")) == name]
        if report.get("cache_requested") and name != "long-first" and not any(hit(r) for r in selected):
            errors.append({"id": name, "no_authenticated_direct_cache_hit": True})
        if name == "long-first" and any(r.get("cache_outcome") == "hit" or r.get("saved_tokens") != 0 for r in selected):
            errors.append({"first_cohort_was_not_cold": True})
    # Same-prompt repeats are necessary independently of token-output equality.
    for first, repeat in [("long-first", "long-repeat"), ("branch-first", "branch-repeat"),
                          ("compute-first", "compute-repeat")]:
        left = [r.get("prompt_token_ids") for r in rows if base_id(r.get("id", "")) == first]
        right = [r.get("prompt_token_ids") for r in rows if base_id(r.get("id", "")) == repeat]
        if not left or left != right:
            errors.append({"repeat_prompt_mismatch": [first, repeat]})
    # Branches must share a substantial prefix yet remain different requests.
    representative = {base_id(r.get("id", "")): r.get("prompt_token_ids", []) for r in rows}
    common_prefix = {}
    anchor = representative.get("long-first", [])
    for name in ("branch-first", "compute-first"):
        other = representative.get(name, [])
        n = next((i for i, pair in enumerate(zip(anchor, other)) if pair[0] != pair[1]), min(len(anchor), len(other)))
        common_prefix[name] = n
        if n < 2500 or anchor == other:
            errors.append({"insufficient_or_identical_branch_prefix": name, "common_tokens": n})
    metrics = {name: {"ttft_s": distribution([r.get("ttft_s") for r in rows if base_id(r.get("id", "")) == name]),
                      "decode_tps": distribution([r.get("decode_tps") for r in rows if base_id(r.get("id", "")) == name]),
                      "hits": sum(hit(r) for r in rows if base_id(r.get("id", "")) == name)} for name in expected}
    return report, {"report": str(Path(path).resolve()), "sha256": sha(path),
                    "concurrency": concurrency, "cache_on": report.get("cache_requested"),
                    "pass": not errors, "errors": errors, "semantic": semantic,
                    "prompt_tokens": distribution([len(r.get("prompt_token_ids", [])) for r in rows]),
                    "shared_prefix_tokens": common_prefix, "metrics": metrics,
                    "exact_generated_tokens_informational": report.get("generated_token_comparisons_pass")}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--benchmarks", required=True, help="Repository scripts/benchmarks directory")
    p.add_argument("--expected", default=str(Path(__file__).with_name("expected.json")))
    p.add_argument("--on", required=True)
    p.add_argument("--off", required=True)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    sys.path.insert(0, a.benchmarks)
    from radix_engine_evidence import report_errors
    expected = load(a.expected)["expected"]
    on, on_result = validate_one(a.on, expected, report_errors)
    off, off_result = validate_one(a.off, expected, report_errors)
    errors = []
    if on.get("cache_requested") is not True or off.get("cache_requested") is not False:
        errors.append("cache_arm_labels_invalid")
    for key in ("input_sha256", "verified_model_hash", "max_concurrent_requests", "resolved_backend", "runtime_identity", "key_mode_requested"):
        if not on.get(key) or on.get(key) != off.get(key):
            errors.append("pair_mismatch_" + key)
    off_rows = {r.get("id"): r for r in off.get("rows", [])}
    pairs = []
    for row in on.get("rows", []):
        other = off_rows.get(row.get("id"), {})
        if row.get("prompt_token_ids") != other.get("prompt_token_ids") or row.get("sampling") != other.get("sampling"):
            errors.append("paired_prompt_or_sampling_mismatch_" + row.get("id", ""))
        cold, warm = other.get("ttft_s"), row.get("ttft_s")
        cold_decode, warm_decode = other.get("decode_tps"), row.get("decode_tps")
        pairs.append({"id": row.get("id"), "on_ttft_s": warm, "off_ttft_s": cold,
                      "ttft_reduction_pct": 100 * (1 - warm / cold) if cold and warm else None,
                      "on_decode_tps": warm_decode, "off_decode_tps": cold_decode,
                      "decode_speed_change_pct": 100 * (warm_decode / cold_decode - 1) if cold_decode and warm_decode else None,
                      "authenticated_hit": hit(row),
                      "exact_tokens_equal_informational": row.get("token_ids") == other.get("token_ids")})
    output = {"schema": 1, "pass": on_result["pass"] and off_result["pass"] and not errors,
              "pair_errors": errors, "on": on_result, "off": off_result, "pairs": pairs,
              "ttft_reduction_pct_hit_rows": distribution([v["ttft_reduction_pct"] for v in pairs if v["authenticated_hit"]]),
              "limitations": ["Small synthetic workload; no broad model quality equivalence claim.",
                "B2/B4 replicate one prompt per cohort; branches run in successive cohorts, not mixed suffixes in one cohort.",
                "Exact output tokens are informational; semantic answer keys and structural gates are mandatory.",
                "Per-row SSD counter deltas can overlap within a batch; terminal hit/staged receipts remain required.",
                "TTFT includes SSD staging and native engine dispatch, not HTTP or coordinator latency.",
                "Fresh-cache matrix only: first cohort must miss; separate-process persistent restart needs its own assertion.",
                "Timing distributions contain few requests and no statistical significance claim."]}
    path = Path(a.output)
    if path.exists():
        raise SystemExit("Refusing to overwrite existing validation result")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"pass": output["pass"], "output": str(path), "pair_errors": errors,
                      "on_errors": len(on_result["errors"]), "off_errors": len(off_result["errors"])}))
    raise SystemExit(0 if output["pass"] else 1)

if __name__ == "__main__":
    main()
