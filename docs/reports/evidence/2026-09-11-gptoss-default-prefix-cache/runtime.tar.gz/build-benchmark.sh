#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gptoss-prefix-20260911
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export RADIX_SOURCE_ROOT="$root/workspace" RADIX_CANDIDATE_BUILD=1
cd "$root/workspace/scripts/benchmarks/radix-engine"
xcrun swift build --force-resolved-versions -c release --scratch-path "$root/benchmark-build" --jobs 4 --product radix-engine > "$root/logs/benchmark-build.log" 2>&1
release="$root/benchmark-build/arm64-apple-macosx/release"
cp -c "$root/artifact/mlx.metallib" "$release/mlx.metallib"
cp -c "$release/radix-engine" "$root/artifact/radix-engine"
for bundle in "$release/"*.bundle; do [ ! -e "$bundle" ] || cp -cR "$bundle" "$root/artifact/"; done
shasum -a 256 "$root/artifact/darkbloom" "$root/artifact/radix-engine" "$root/artifact/mlx.metallib" > "$root/artifact-sha256.txt"
python3 -B "$root/verify_source.py" "$root"
printf PASS > "$root/benchmark-result.txt"
