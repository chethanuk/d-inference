#!/usr/bin/env python3
"""Analyze retained rollout SSE timing without running a model or changing inputs.

Usage: python3 analyze_rollout_content_gaps.py PATH/TO/review-evidence.json
Outputs content-gap-analysis.json and .md alongside that input by default.
Only successive nonempty delta.content payloads count. TTFT and terminal drain
are reported separately and never treated as inter-content gaps. Request zero
is excluded from phase aggregates by default because it includes target loading.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path


def distribution(values):
    values = sorted(values)
    if not values:
        return {"n": 0, "p50_s": None, "p95_s": None, "max_s": None}
    return {"n": len(values), "p50_s": values[math.ceil(len(values) * .50) - 1],
            "p95_s": values[math.ceil(len(values) * .95) - 1], "max_s": values[-1]}


def content_times(events):
    times = []
    for event in events:
        payload = event.get("data")
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except ValueError:
                continue
        if not isinstance(payload, dict):
            continue
        if not any(isinstance(c.get("delta", {}).get("content"), str)
                   and c["delta"]["content"] for c in payload.get("choices", [])):
            continue
        elapsed = event.get("elapsed_s")
        if not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed < 0:
            raise ValueError("Content payload has no valid elapsed timestamp")
        if times and elapsed < times[-1]:
            raise ValueError("Content timestamps are not monotonic")
        times.append(elapsed)
    return times


def analyze(evidence, excluded):
    samples = sorted((s for s in evidence["metrics"] if "mtp_active" in s.get("values", {})),
                     key=lambda s: s["monotonic"])
    inactive = next((s for s in samples if s["values"]["mtp_active"] == 0), None)
    active = next((s for s in samples if inactive and s["monotonic"] > inactive["monotonic"]
                   and s["values"]["mtp_active"] == 1), None)
    active_time = active["monotonic"] if active else None
    positive = next((s for s in samples if active and s["monotonic"] >= active_time
                     and s["values"].get("mtp_rounds_total", 0) > 0), None)
    last_zero = next((s for s in reversed(samples) if positive
                      and s["monotonic"] < positive["monotonic"]
                      and s["values"].get("mtp_rounds_total", 0) == 0), None)
    rows, gaps = [], []
    for request in evidence["requests"]:
        times = content_times(request.get("response", {}).get("events", []))
        start, end = request["started_monotonic"], request["ended_monotonic"]
        index = request["index"]
        overlap = active_time is not None and start <= active_time <= end
        positive_window_overlap = (last_zero is not None and positive is not None
                                   and start <= positive["monotonic"] and end >= last_zero["monotonic"])
        classified_phase = "activation_overlap" if overlap else request["phase_at_start"]
        request_gaps = [{"request_index": index, "content_pair_index": i,
                         "gap_s": b - a, "start_elapsed_s": a, "end_elapsed_s": b,
                         "start_monotonic": start + a, "end_monotonic": start + b,
                         "classified_phase": classified_phase}
                        for i, (a, b) in enumerate(zip(times, times[1:]))]
        response = request.get("response", {})
        rows.append({"index": index, "original_phase_at_start": request["phase_at_start"],
                     "classified_phase": classified_phase,
                     "activation_overlap": overlap,
                     "overlaps_first_positive_counter_window": positive_window_overlap,
                     "excluded_from_phase_aggregates": index in excluded,
                     "valid": request.get("valid", False), "http_status": request.get("status"),
                     "started_monotonic": start, "ended_monotonic": end,
                     "ttft_s": response.get("ttft_s"), "total_s": request["elapsed_s"],
                     "completion_tokens": response.get("usage", {}).get("completion_tokens"),
                     "content_payload_count": len(times),
                     "first_content_elapsed_s": times[0] if times else None,
                     "last_content_elapsed_s": times[-1] if times else None,
                     "content_gap_distribution": distribution([g["gap_s"] for g in request_gaps]),
                     "maximum_content_gap": max(request_gaps, key=lambda g: g["gap_s"], default=None)})
        gaps.extend(request_gaps)
    included = [r for r in rows if not r["excluded_from_phase_aggregates"]]
    included_gaps = [g for g in gaps if g["request_index"] not in excluded]
    phases = {}
    for phase in sorted({r["classified_phase"] for r in included}):
        selected = [r for r in included if r["classified_phase"] == phase]
        phases[phase] = {"request_indices": [r["index"] for r in selected],
                         "content_gaps": distribution([g["gap_s"] for g in included_gaps if g["classified_phase"] == phase]),
                         "ttft": distribution([r["ttft_s"] for r in selected if r["ttft_s"] is not None]),
                         "total": distribution([r["total_s"] for r in selected])}
    return {"requests": rows, "phases": phases, "excluded_request_indices": sorted(excluded),
            "valid_requests": sum(r["valid"] for r in rows), "request_count": len(rows),
            "maximum_content_gap_excluding_initial_requests": max(included_gaps, key=lambda g: g["gap_s"], default=None),
            "first_active_sample_monotonic": active_time,
            "first_positive_counter_window": {"last_zero_sample_monotonic": last_zero["monotonic"] if last_zero else None,
                                               "first_positive_sample_monotonic": positive["monotonic"] if positive else None,
                                               "candidate_request_indices": [r["index"] for r in rows if r["overlaps_first_positive_counter_window"]]},
            "limitations": ["Client-observed content payload spacing, not device token timing. Excludes initial wait and final drain from gaps.",
                            "Activation is bracketed by periodic metrics observations; original phase_at_start can be stale.",
                            "A pause near first verification does not establish JIT or another internal cause.",
                            "Response lengths vary; raw total latency is not a matched-workload decode performance comparison.",
                            "This single-host sequential B1 trace does not establish a fleet-wide latency bound."]}


def markdown(result):
    maximum = result["maximum_content_gap_excluding_initial_requests"]
    lines = ["# Rollout streamed-content timing", "",
             f"{result['valid_requests']}/{result['request_count']} requests were structurally valid.", "",
             "Gaps are between successive nonempty `delta.content` payloads. They exclude TTFT and post-content terminal drain. "
             f"Phase aggregates exclude request(s) {result['excluded_request_indices']} (initial target load).", "",
             "| Observed phase | Requests | Max content gap | Max TTFT | Max total |",
             "|---|---:|---:|---:|---:|"]
    for phase, values in result["phases"].items():
        gap = values["content_gaps"]["max_s"]
        lines.append(f"| {phase} | {len(values['request_indices'])} | {gap * 1000:.3f} ms | "
                     f"{values['ttft']['max_s']:.6f} s | {values['total']['max_s']:.6f} s |")
    if maximum:
        row = next(r for r in result["requests"] if r["index"] == maximum["request_index"])
        lines += ["", f"The largest observed gap was **{maximum['gap_s'] * 1000:.3f} ms** in request {row['index']}, "
                  f"between monotonic {maximum['start_monotonic']:.6f} and {maximum['end_monotonic']:.6f}. "
                  f"That request's TTFT was {row['ttft_s']:.6f} s and total latency {row['total_s']:.6f} s "
                  f"({row['completion_tokens']} completion tokens)."]
    window = result["first_positive_counter_window"]
    lines += ["", f"First active sample: `{result['first_active_sample_monotonic']}`. "
              f"First positive MTP counter is bracketed by `{window['last_zero_sample_monotonic']}` and "
              f"`{window['first_positive_sample_monotonic']}`; overlapping request(s): {window['candidate_request_indices']}.",
              "", "Requests overlapping the first active sample are classified as `activation_overlap`, regardless of a stale "
              "`phase_at_start`. `waiting_weights` otherwise retains the runner's label and includes background preparation after download.",
              "", "Successful streams and normal TTFT do not establish zero latency cost: inspect the content gaps and total latency too. "
              "No causal JIT attribution is made.", "", "Limitations:", ""]
    lines += [f"- {s}" for s in result["limitations"]]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--output-prefix", type=Path)
    parser.add_argument("--exclude-request", type=int, action="append")
    args = parser.parse_args()
    result = analyze(json.loads(args.evidence.read_text()), set(args.exclude_request or [0]))
    result["provenance"] = {"evidence_path": str(args.evidence.resolve()),
                             "evidence_sha256": hashlib.sha256(args.evidence.read_bytes()).hexdigest(),
                             "analysis_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    prefix = args.output_prefix or args.evidence.parent / "content-gap-analysis"
    prefix.parent.mkdir(parents=True, exist_ok=True)
    prefix.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    prefix.with_suffix(".md").write_text(markdown(result))
    print(prefix.with_suffix(".json"))
    print(prefix.with_suffix(".md"))


if __name__ == "__main__":
    main()
