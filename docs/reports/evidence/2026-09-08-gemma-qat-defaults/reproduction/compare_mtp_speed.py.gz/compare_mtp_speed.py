"""Summarize paired native reports; retain differences, do not declare release acceptance."""
import argparse,json,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('off_report');p.add_argument('on_report');a=p.parse_args()
off=json.loads(Path(a.off_report).read_text());on=json.loads(Path(a.on_report).read_text())
rows=[]
for left,right in zip(off['rows'],on['rows']):
 if left['id']!=right['id']:raise ValueError('row identity differs')
 def exposure(x):
  n=x.get('decode_tokens_after_first_delta',0);tps=x.get('decode_tps',0)
  before=x.get('metrics_before',{}).get('mtp',{});after=x.get('metrics_after',{}).get('mtp',{})
  delta={k:after.get(k,0)-before.get(k,0) for k in ['rounds','proposed_tokens','accepted_tokens','emitted_tokens','rectangular_rounds','serial_rounds','seed_steps']}
  for k in ['depth_selections','controller_fallbacks']:
   delta[k]={depth:value-before.get(k,{}).get(depth,0) for depth,value in after.get(k,{}).items()}
  delta['acceptance_rate']=delta['accepted_tokens']/delta['proposed_tokens'] if delta['proposed_tokens'] else None
  return {'mtp_delta':delta,'completion_tokens':x.get('completion_tokens'),'decode_tokens':n,'decode_seconds':n/tps if tps else None,'decode_tps':tps,'ttft_s':x.get('ttft_s'),'elapsed_s':x.get('elapsed_s'),'finish':x.get('finish'),'cache_outcome':x.get('cache_outcome'),'saved_tokens':x.get('saved_tokens'),'mtp':x.get('metrics_after',{}).get('mtp')}
 l,r=exposure(left),exposure(right)
 rows.append({'id':left['id'],'prompt_tokens_equal':left.get('prompt_token_ids')==right.get('prompt_token_ids'),'generated_tokens_equal':left.get('token_ids')==right.get('token_ids'),'off':l,'on':r,'on_over_off_decode_ratio':r['decode_tps']/l['decode_tps'] if l['decode_tps'] else None,'substantial_exposure_both':all(v['decode_tokens']>=256 and v['decode_seconds'] is not None and v['decode_seconds']>=3 for v in [l,r]),'manual_semantic_review_required':True})
if len(off['rows'])!=len(on['rows']):raise ValueError('row count differs')
print(json.dumps({'off_status':off['status'],'on_status':on['status'],'rows':rows,'warning':'An initial speed ratio is descriptive only. Review semantic behavior and restored cache counters, then confirm promising gains in reversed run order before enabling defaults.'},indent=2))
