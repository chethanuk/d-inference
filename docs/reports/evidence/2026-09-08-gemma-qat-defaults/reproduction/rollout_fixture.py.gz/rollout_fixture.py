#!/usr/bin/env python3
"""Owned loopback catalog/CDN fixture. Importing starts no server or process."""
import hashlib
import http.server
import json
from pathlib import Path
import re
import threading
import time
import urllib.parse
import uuid

PINNED_ASSISTANT_AGGREGATE = "d8c5fae1f4b7a07376c9f0b92f3ec283ba276d57ec3b675d8cf758a79d73bd34"


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def make_fixture(assistant, model, output, expected_aggregate=PINNED_ASSISTANT_AGGREGATE):
    assistant = Path(assistant).absolute()
    if assistant.is_symlink() or not assistant.is_dir():
        raise ValueError("Assistant fixture must be a real flat directory")
    files = []
    for path in sorted(assistant.iterdir()):
        if path.is_symlink() or not path.is_file() or not re.fullmatch(r"[A-Za-z0-9_.-]+", path.name):
            raise ValueError(f"Unexpected assistant fixture member: {path.name}")
        role = "config" if path.name == "config.json" else "weight" if path.suffix == ".safetensors" else None
        if role is None or path.stat().st_size <= 0:
            raise ValueError(f"Unexpected assistant fixture member: {path.name}")
        files.append({"path": path.name, "size_bytes": path.stat().st_size,
                      "sha256": sha256_file(path), "role": role})
    if not any(f["role"] == "config" for f in files) or not any(f["role"] == "weight" for f in files):
        raise ValueError("Assistant needs config.json and safetensors")
    aggregate = hashlib.sha256(b"".join(bytes.fromhex(f["sha256"]) for f in files)).hexdigest()
    if aggregate != expected_aggregate:
        raise ValueError(f"Assistant identity mismatch: {aggregate}")
    revision = "rollout-" + uuid.uuid4().hex
    prefix = "v2-specdec/gemma-qat-local-rollout/" + revision
    artifact_key = hashlib.sha256(prefix.encode()).hexdigest()
    store = Path.home() / ".darkbloom/spec-dec"
    destination = store / artifact_key
    if destination.exists() or destination.is_symlink() or list(store.glob(".staging-" + artifact_key + "-*")):
        raise ValueError("Unique owned artifact namespace already exists")
    manifest = {"schema_version": 1, "model_id": "fixture/gemma-qat-assistant",
                "version": revision, "r2_prefix": prefix, "aggregate_sha256": aggregate,
                "total_size_bytes": sum(f["size_bytes"] for f in files), "file_count": len(files),
                "files": files, "created_at": "2026-09-08T00:00:00Z"}
    manifest_bytes = json_bytes(manifest)
    reference = {"r2_prefix": prefix, "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                 "total_size_bytes": manifest["total_size_bytes"], "file_count": len(files),
                 "max_file_count": len(files), "allowed_file_types": ["config", "weight"],
                 "config_sha256": next(f["sha256"] for f in files if f["role"] == "config"),
                 "revision": revision}
    catalog = {"models": [{"id": model, "s3_name": "unused-local-rollout-target",
                           "display_name": "Gemma QAT local rollout fixture", "model_type": "text",
                           "size_gb": 15, "metadata": {"spec_dec": reference}}], "aliases": []}
    Path(output, "fixture-manifest.json").write_bytes(manifest_bytes)
    Path(output, "fixture-catalog.json").write_bytes(json_bytes(catalog))
    return {"assistant_directory": str(assistant), "manifest": manifest, "manifest_bytes": manifest_bytes,
            "catalog": catalog, "r2_prefix": prefix, "artifact_key": artifact_key,
            "owned_artifact_directory": str(destination), "store_root": str(store)}


class RolloutFixtureServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def __init__(self, port, fixture, output, failure="none"):
        self.fixture = fixture
        self.output = Path(output)
        self.failure = failure
        self.metadata_release = threading.Event()
        self.weights_release = threading.Event()
        self.weight_requested = threading.Event()
        self.failure_served = threading.Event()
        self.stop_event = threading.Event()
        self._lock = threading.Lock()
        super().__init__(("127.0.0.1", port), FixtureHandler)

    def log_event(self, **event):
        event.update(unix=time.time(), monotonic=time.monotonic())
        with self._lock, (self.output / "fixture-requests.jsonl").open("a") as stream:
            stream.write(json.dumps(event) + "\n")

    def await_gate(self, gate):
        deadline = time.monotonic() + 180
        while not gate.wait(0.1):
            if self.stop_event.is_set() or time.monotonic() >= deadline:
                return False
        return not self.stop_event.is_set()


class FixtureHandler(http.server.BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass

    def do_GET(self):
        fixture = self.server.fixture
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        self.server.log_event(event="request", path=path, range=self.headers.get("Range"))
        try:
            if path == "/v1/models/catalog":
                if not self.server.await_gate(self.server.metadata_release):
                    return self.send_payload(503, b"fixture stopping")
                return self.send_payload(200, json_bytes(fixture["catalog"]), "application/json")
            if path == "/" + fixture["r2_prefix"] + "/manifest.json":
                data = fixture["manifest_bytes"]
                if self.server.failure == "manifest-digest":
                    data += b" "  # valid JSON with a deliberately wrong raw-byte digest
                    self.server.failure_served.set()
                return self.send_payload(200, data, "application/json")
            member = next((f for f in fixture["manifest"]["files"]
                           if path == "/" + fixture["r2_prefix"] + "/" + f["path"]), None)
            if member is None:
                return self.send_payload(404, b"not a fixture route")
            if member["role"] == "weight":
                self.server.weight_requested.set()
                if not self.server.await_gate(self.server.weights_release):
                    return self.send_payload(503, b"fixture stopping")
                if self.server.failure == "weight-http":
                    self.server.failure_served.set()
                    return self.send_payload(503, b"intentional rollout fixture download failure")
            start = 0
            if self.headers.get("Range"):
                match = re.fullmatch(r"bytes=(\d+)-", self.headers["Range"])
                if match is None or int(match[1]) >= member["size_bytes"]:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{member['size_bytes']}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                start = int(match[1])
            status = 206 if self.headers.get("Range") else 200
            self.send_response(status)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(member["size_bytes"] - start))
            self.send_header("Accept-Ranges", "bytes")
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{member['size_bytes'] - 1}/{member['size_bytes']}")
            self.end_headers()
            with Path(fixture["assistant_directory"], member["path"]).open("rb") as source:
                source.seek(start)
                while not self.server.stop_event.is_set():
                    block = source.read(1024 * 1024)
                    if not block:
                        break
                    self.wfile.write(block)
            self.server.log_event(event="file_sent", path=path, status=status, start=start)
        except (BrokenPipeError, ConnectionResetError, TimeoutError) as error:
            self.server.log_event(event="client_closed", path=path, error=str(error))
        except Exception as error:
            self.server.log_event(event="handler_error", path=path, error=repr(error))

    def send_payload(self, status, payload, content_type="text/plain"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)
        self.server.log_event(event="response", path=self.path, status=status, bytes=len(payload))
