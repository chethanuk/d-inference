#!/usr/bin/env python3
"""Bounded real-model HTTP rollout probe. Run only on the dedicated model host.

Owns one provider process group and a localhost fixture server. Default MTP,
KV backend, and prefix-cache policy are left unconfigured. Fixture metadata
gets a unique identity; assistant bytes are verified against their pinned hash.
No shared cache deletion, HOME override, installation, or daemon registration.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

from radix_prefix_cache import collect, events, body, PARAGRAPH
from rollout_fixture import make_fixture, RolloutFixtureServer, sha256_file
from run_default_http import ranked_job, terminate


def metric_values(raw, model):
    result = {}
    for line in raw.splitlines():
        match = re.fullmatch(r'(mtp_[a-z_]+)\{model="((?:\\.|[^"\\])*)"(?:,reason="((?:\\.|[^"\\])*)")?\} ([0-9.eE+-]+)', line)
        if match and json.loads('"' + match[2] + '"') == model:
            result[match[1]] = float(match[4])
            if match[3] is not None:
                result["inactive_reason"] = json.loads('"' + match[3] + '"')
    return result


def distribution(values):
    ordered = sorted(v for v in values if v is not None)
    if not ordered:
        return {"n": 0, "p50_s": None, "p95_s": None, "max_s": None}
    return {"n": len(ordered), "p50_s": ordered[math.ceil(0.50 * len(ordered)) - 1],
            "p95_s": ordered[math.ceil(0.95 * len(ordered)) - 1], "max_s": ordered[-1]}


def request_once(base, request_body, output, index, phase, timeout):
    started = time.perf_counter()
    record = {"index": index, "phase_at_start": phase, "started_unix": time.time(),
              "started_monotonic": time.monotonic(), "body": request_body, "valid": False}
    request = urllib.request.Request(base + "/v1/chat/completions",
                                     data=json.dumps(request_body).encode(),
                                     headers={"Content-Type": "application/json"})
    with Path(output, f"request-{index:04d}-sse.jsonl").open("w") as raw:
        def payloads(response):
            for payload in events(response):
                raw.write(json.dumps({"elapsed_s": time.perf_counter() - started, "data": payload}) + "\n")
                raw.flush()
                yield payload
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                record["status"] = response.status
                record["headers"] = dict(response.headers)
                record["response"] = collect(payloads(response), started)
            if not record["response"]["text"].strip():
                raise RuntimeError("No visible answer text")
            record["valid"] = True
        except urllib.error.HTTPError as error:
            record.update(status=error.code, error=str(error), error_body=error.read(65536).decode(errors="replace"))
        except Exception as error:
            record["error"] = repr(error)
    record.update(ended_unix=time.time(), ended_monotonic=time.monotonic(), elapsed_s=time.perf_counter() - started)
    Path(output, f"request-{index:04d}.json").write_text(json.dumps(record, indent=2))
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--assistant-directory", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model", default="gemma-4-26b-qat-4bit")
    parser.add_argument("--port", type=int, default=18128)
    parser.add_argument("--fixture-port", type=int, default=18129)
    parser.add_argument("--failure", choices=["none", "manifest-digest", "weight-http"], default="none")
    parser.add_argument("--duration", type=float, default=300)
    parser.add_argument("--request-timeout", type=float, default=120)
    parser.add_argument("--max-requests", type=int, default=120)
    parser.add_argument("--blocked-requests", type=int, default=2)
    parser.add_argument("--after-requests", type=int, default=12)
    parser.add_argument("--max-tokens", type=int, default=256)
    parser.add_argument("--source-revision", required=True)
    parser.add_argument("--lm-revision", required=True)
    parser.add_argument("--mlx-revision", required=True)
    parser.add_argument("--target-sha256", default="2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785")
    args = parser.parse_args()
    if not 30 <= args.duration <= 1800 or args.request_timeout <= 0 or args.max_requests < 1 or args.blocked_requests < 1 or args.after_requests < 1 or not 1 <= args.max_tokens <= 2048:
        raise SystemExit("Invalid probe bounds")
    if args.port == args.fixture_port:
        raise SystemExit("Provider and fixture ports must differ")
    if ranked_job() or subprocess.run(["pgrep", "-x", "darkbloom"], stdout=subprocess.DEVNULL).returncode == 0:
        raise SystemExit("Dedicated host is busy")
    if (Path.home() / "Library/Caches/darkbloom/kv").exists():
        raise SystemExit("Retired shared cache exists; this probe must not trigger its cleanup")
    for port in (args.port, args.fixture_port):
        with socket.socket() as check:
            check.bind(("127.0.0.1", port))
    root = Path(args.output).absolute()
    root.mkdir(parents=True, exist_ok=False)
    fixture = make_fixture(args.assistant_directory, args.model, root)
    binary = Path(args.binary).resolve(strict=True)
    metadata = {"arguments": vars(args), "binary": str(binary), "binary_sha256": sha256_file(binary),
                "started_unix": time.time(), "source_revision": args.source_revision,
                "lm_revision": args.lm_revision, "mlx_revision": args.mlx_revision,
                "target_sha256_reported_from_separate_verification": args.target_sha256,
                "assistant_aggregate_sha256_verified": fixture["manifest"]["aggregate_sha256"],
                "owned_artifact_directory": fixture["owned_artifact_directory"],
                "r2_prefix": fixture["r2_prefix"], "fixture_manifest_sha256": hashlib.sha256(fixture["manifest_bytes"]).hexdigest(),
                "scope": "Real default-auto serving through controlled localhost catalog/CDN; identical pinned assistant bytes, unique test manifest identity. HF hint omitted to exercise delayed CDN. Does not validate public catalog or HF-first transport.",
                "helper_sha256": {p: sha256_file(Path(__file__).with_name(p)) for p in
                                  ("run_mtp_rollout_http.py", "rollout_fixture.py", "radix_prefix_cache.py", "run_default_http.py")}}
    env = os.environ.copy()
    removed = []
    for key in list(env):
        if key in ("DARKBLOOM_PREFIX_CACHE", "DARKBLOOM_CBV2_PAGED_KV", "DARKBLOOM_CBV2_MTP") or key.startswith(("DARKBLOOM_MTP_", "DARKBLOOM_QWEN_", "DARKBLOOM_GEMMA_", "DARKBLOOM_GEMMA4_", "DARKBLOOM_CBV2_")):
            removed.append(key)
            del env[key]
    selected = {"DARKBLOOM_NO_UPDATE_CHECK": "1", "DARKBLOOM_PID_FILE": str(root / "provider.pid"),
                "DARKBLOOM_LOCAL_DIR": str(root / "local"), "DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL": "1",
                "DARKBLOOM_PREFIX_CACHE_TEST_ROOT": str(root / "prefix-cache"),
                "DARKBLOOM_PREFIX_CACHE_STATS_INTERVAL_SECS": "1",
                "DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY": "0",
                "DARKBLOOM_R2_CDN_URL": f"http://127.0.0.1:{args.fixture_port}"}
    env.update(selected)
    metadata.update(environment=selected, cleared_environment_keys=removed,
                    omitted_settings=["mtp_mode", "mtp_drafter_path", "engine_v2_kv_backend"])
    config = root / "provider.toml"
    config.write_text(f'''config_version = 3
[backend]
enabled_models = [{json.dumps(args.model)}]
engine_v2_max_concurrent = 1
idle_timeout_mins = 60
max_model_slots = 1
port = {args.port}
preload_models = []
startup_preload = false
startup_selftest = false
startup_selftest_fail_closed = false
[coordinator]
heartbeat_interval_secs = 30
private_only = true
url = "ws://127.0.0.1:{args.fixture_port}/ws/provider"
[provider]
auto_restart = false
auto_update = false
memory_reserve_gb = 2
name = "isolated-gemma-mtp-rollout"
''')
    base = f"http://127.0.0.1:{args.port}"
    stop = threading.Event()
    samples, records = [], []
    sample_lock = threading.Lock()
    owned_provider = None
    fixture_server = None
    threads = []
    abort = []
    failure_started = None
    after = []
    termination_lock = threading.Lock()

    def terminate_owned():
        with termination_lock:
            try:
                terminate(owned_provider)
            except ProcessLookupError:
                pass

    deadline = time.monotonic() + args.duration

    def scrape():
        while not stop.is_set():
            sample = {"unix": time.time(), "monotonic": time.monotonic()}
            try:
                with urllib.request.urlopen(base + "/metrics", timeout=2) as response:
                    raw = response.read(2 * 1024 * 1024).decode()
                sample.update(raw=raw, values=metric_values(raw, args.model))
            except Exception as error:
                sample["error"] = repr(error)
            with sample_lock:
                samples.append(sample)
            with (root / "metrics.jsonl").open("a") as stream:
                stream.write(json.dumps(sample) + "\n")
            stop.wait(0.25)

    def watchdog():
        while not stop.wait(1):
            reason = "deadline" if time.monotonic() >= deadline else "ranked job appeared" if ranked_job() else None
            if reason:
                abort.append(reason)
                terminate_owned()
                return

    try:
        fixture_server = RolloutFixtureServer(args.fixture_port, fixture, root, args.failure)
        serving = threading.Thread(target=fixture_server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
        serving.start()
        threads.append(serving)
        with (root / "server.log").open("w") as server_log:
            command = [str(binary), "start", "--local", "--config", str(config), "--model", args.model,
                       "--port", str(args.port), "--no-auth"]
            metadata["command"] = command
            owned_provider = subprocess.Popen(command, env=env, stdout=server_log, stderr=subprocess.STDOUT, start_new_session=True)
            for action in (scrape, watchdog):
                thread = threading.Thread(target=action, daemon=True)
                thread.start()
                threads.append(thread)
            while time.monotonic() < deadline:
                if owned_provider.poll() is not None:
                    raise RuntimeError("Provider exited before health")
                try:
                    with urllib.request.urlopen(base + "/health", timeout=1):
                        break
                except OSError:
                    time.sleep(0.25)
            else:
                raise RuntimeError("Provider did not become healthy before deadline")
            metadata["healthy_unix"] = time.time()
            weight_baseline = None
            failure_started = None
            for index in range(args.max_requests):
                if abort or owned_provider.poll() is not None:
                    break
                with sample_lock:
                    latest = next((s.get("values", {}) for s in reversed(samples) if "values" in s), {})
                phase = "active" if latest.get("mtp_active") == 1 else "waiting_weights" if fixture_server.metadata_release.is_set() else "waiting_metadata"
                request_body = body(args.model, [
                    {"role": "system", "content": "Answer plainly and accurately. Do not include hidden reasoning."},
                    {"role": "user", "content": PARAGRAPH * 12 + f"\nRequest {index}: Give twelve numbered, specific implementation checks for the proposed work. Explain each in one sentence. Do not invent approved funding or outcomes."}], args.max_tokens)
                record = request_once(base, request_body, root, index, phase, args.request_timeout)
                records.append(record)
                valid = sum(r["valid"] for r in records)
                if not fixture_server.metadata_release.is_set() and valid >= args.blocked_requests:
                    metadata["metadata_released_monotonic"] = time.monotonic()
                    fixture_server.metadata_release.set()
                if fixture_server.weight_requested.is_set() and weight_baseline is None:
                    weight_baseline = valid
                    metadata["weight_requested_observed_monotonic"] = time.monotonic()
                if weight_baseline is not None and valid - weight_baseline >= args.blocked_requests and not fixture_server.weights_release.is_set():
                    metadata["weights_released_monotonic"] = time.monotonic()
                    fixture_server.weights_release.set()
                if fixture_server.failure_served.is_set() and failure_started is None:
                    failure_started = time.monotonic()
                    metadata["failure_first_observed_monotonic"] = failure_started
                if args.failure != "none":
                    after = [r for r in records if failure_started is not None and r["started_monotonic"] >= failure_started]
                    if len(after) >= args.after_requests and time.monotonic() - failure_started >= 30:
                        break
                elif sum(r["valid"] and r["phase_at_start"] == "active" for r in records) >= args.after_requests:
                    break
                if sum(not r["valid"] for r in records) >= 3:
                    break
                time.sleep(0.1)  # sustained B1 load, with a normal request boundary
    except Exception as error:
        metadata["error"] = repr(error)
    finally:
        metadata["provider_exit_before_cleanup"] = owned_provider.poll() if owned_provider else None
        stop.set()
        terminate_owned()
        if fixture_server:
            fixture_server.stop_event.set()
            fixture_server.metadata_release.set()
            fixture_server.weights_release.set()
            fixture_server.shutdown()
            fixture_server.server_close()
        for thread in threads:
            thread.join(timeout=3)
        metadata.update(ended_unix=time.time(), abort_reasons=abort,
                        provider_exit_code=owned_provider.poll() if owned_provider else None,
                        owned_artifact_present=Path(fixture["owned_artifact_directory"]).is_dir(),
                        owned_staging_left=[str(p) for p in Path(fixture["store_root"]).glob(".staging-" + fixture["artifact_key"] + "-*")])
        usable = [s for s in samples if "mtp_active" in s.get("values", {})]
        zero = next((s for s in usable if s["values"]["mtp_active"] == 0), None)
        active = next((s for s in usable if zero and s["monotonic"] > zero["monotonic"] and s["values"]["mtp_active"] == 1), None)
        rounds = max((s["values"].get("mtp_rounds_total", 0) for s in usable), default=0)
        valid_records = [r for r in records if r["valid"]]
        metadata_blocked = [r for r in valid_records if r["ended_monotonic"] <= metadata.get("metadata_released_monotonic", -1)]
        weights_blocked = [r for r in valid_records if r["started_monotonic"] >= metadata.get("weight_requested_observed_monotonic", float("inf")) and r["ended_monotonic"] <= metadata.get("weights_released_monotonic", -1)]
        report = {"valid_requests_while_metadata_blocked": len(metadata_blocked),
                  "valid_requests_while_weights_blocked": len(weights_blocked), "requests": len(records), "valid_requests": len(valid_records),
                  "interrupted_or_invalid_streams": sum(not r["valid"] and r.get("status", 200) < 400 for r in records),
                  "serving_5xx": sum(500 <= r.get("status", 0) < 600 for r in records),
                  "serving_non_2xx": sum(not 200 <= r.get("status", 0) < 300 for r in records),
                  "observed_target_only": zero is not None, "observed_activation_transition": active is not None,
                  "first_active_monotonic": active["monotonic"] if active else None,
                  "mtp_rounds_max": rounds,
                  "mtp_rounds_after_activation_max": max((s["values"].get("mtp_rounds_total", 0) for s in usable if active and s["monotonic"] >= active["monotonic"]), default=0),
                  "fixture_failure_served": fixture_server.failure_served.is_set() if fixture_server else False,
                  "latency": {phase: {"ttft": distribution(r["response"].get("ttft_s") for r in valid_records if phase == "all" or r["phase_at_start"] == phase),
                                      "total": distribution(r["elapsed_s"] for r in valid_records if phase == "all" or r["phase_at_start"] == phase)}
                              for phase in ("all", "waiting_metadata", "waiting_weights", "active")},
                  "limitations": ["Descriptive latency only; phases include startup/cache/compile differences and are not a decode speed A/B.",
                                   "SSE structural validity is checked and full answers retained; human semantic review is still required.",
                                   "Counter can reset at engine replacement; maximum is reported, not sum across engine lifetimes."]}
        checks = {
            "all_serving_requests_valid": bool(records) and len(records) == len(valid_records),
            "no_runner_error_or_abort": not metadata.get("error") and not abort,
            "provider_alive_until_cleanup": metadata["provider_exit_before_cleanup"] is None,
            "requests_served_during_metadata_delay": len(metadata_blocked) >= args.blocked_requests,
            "initial_target_only_metrics": zero is not None
                and zero["monotonic"] < metadata.get("metadata_released_monotonic", 0),
        }
        if args.failure == "none":
            checks.update({
                "requests_served_during_weight_delay": len(weights_blocked) >= args.blocked_requests,
                "activation_after_weight_release": active is not None
                    and active["monotonic"] > metadata.get("weights_released_monotonic", float("inf")),
                "real_mtp_rounds_after_activation": report["mtp_rounds_after_activation_max"] > 0,
                "enough_active_requests": sum(r["phase_at_start"] == "active" for r in valid_records)
                    >= args.after_requests,
            })
        else:
            checks.update({
                "injected_failure_reached": report["fixture_failure_served"],
                "remained_target_only": not any(s["values"]["mtp_active"] == 1 for s in usable)
                    and rounds == 0,
                "failure_observed_for_30_seconds": failure_started is not None
                    and time.monotonic() - failure_started >= 30,
                "enough_requests_after_failure": len(after) >= args.after_requests,
                "requests_served_during_weight_delay": args.failure != "weight-http"
                    or len(weights_blocked) >= args.blocked_requests,
            })
        report["checks"] = checks
        report["passed"] = all(checks.values())
        (root / "metadata.json").write_text(json.dumps(metadata, indent=2))
        (root / "report.json").write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, lambda signum, frame: sys.exit(128 + signum))
    raise SystemExit(main())
