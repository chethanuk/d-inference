"""Post-activation vision/tools on the rollout runner's already-owned provider.
No process/server creation. Reuses retained image/tools and the existing SSE parser.
"""
import base64
import hashlib
import json
from pathlib import Path
import time
import urllib.request

from radix_prefix_cache import body, collect, events, metrics
from run_mtp_rollout_http import metric_values

IMAGE_SHA256 = 'f9f9fbf8c0a05fbac1081db94dff3688cdcb3ee3425e2c18e51cbe90f3c5cb33'


def tool_calls(response):
    result = {}
    for frame in response['events']:
        if frame['data'] == '[DONE]':
            continue
        for choice in json.loads(frame['data']).get('choices', []):
            for call in choice.get('delta', {}).get('tool_calls', []):
                item = result.setdefault(str(call.get('index', 0)), {'name': '', 'arguments': ''})
                function = call.get('function', {})
                item['name'] += function.get('name') or ''
                item['arguments'] += function.get('arguments') or ''
    return result


def inventory(root):
    files = []
    for path in sorted(Path(root).rglob('*')):
        if path.is_file():
            stat = path.stat()
            files.append({'path': str(path.relative_to(root)), 'bytes': stat.st_size,
                          'mtime_ns': stat.st_mtime_ns})
    return files


def run_capabilities(base, model, output, image_path, tool_fixture, timeout, cache_root):
    output = Path(output)
    output.mkdir(exist_ok=False)
    image = Path(image_path).read_bytes()
    if hashlib.sha256(image).hexdigest() != IMAGE_SHA256:
        raise RuntimeError('Prior release vision fixture identity mismatch')
    (output/'cube-hero.png').write_bytes(image)
    image_url = 'data:image/png;base64,' + base64.b64encode(image).decode()
    vision = body(model, [{'role': 'user', 'content': [
        {'type': 'image_url', 'image_url': {'url': image_url}},
        {'type': 'text', 'text': 'Describe the central three-dimensional object and surrounding application interface in four concise sentences. Mention shapes, colors, background, and visible controls. Report only visible details.'},
    ]}], 192)
    tool = json.loads(Path(tool_fixture).read_text())
    tool.update(model=model, stream=True, stream_options={'include_usage': True},
                chat_template_kwargs={'enable_thinking': False})
    records = []
    report = {'image_sha256': IMAGE_SHA256, 'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Same default-auto rollout provider after successful text activation; local diagnostic catalog with verified assistant bytes.',
              'semantic_review_required': True, 'records': records,
              'cache_inventory_scope': 'Descriptive only: prior text checkpoint writes may still be draining; unchanged files do not prove absence of reads.',
              'cold_cache_scope': 'Multimodal lookup/staging is source-gated off. Explicit cached_tokens is retained when exposed; absent detail is not treated as zero. Directory snapshots cannot prove absence of reads.',
              'passed': False}
    try:
        for name, request_body in [('vision-first', vision), ('vision-repeat', vision), ('tools', tool)]:
            before = metrics(base)
            before_values = metric_values(before, model)
            (output/(name+'-metrics-before.txt')).write_text(before)
            if before_values.get('mtp_active') != 1:
                raise RuntimeError('Capability requests require actual active MTP slot')
            before_inventory = inventory(cache_root)
            started = time.perf_counter()
            record = {'name': name, 'request': request_body, 'started_unix': time.time(),
                      'mtp_before': before_values, 'cache_inventory_before': before_inventory}
            records.append(record)
            request = urllib.request.Request(base+'/v1/chat/completions',
                      data=json.dumps(request_body).encode(), headers={'Content-Type':'application/json'})
            with (output/(name+'-sse.jsonl')).open('w') as raw:
                def payloads(response):
                    for payload in events(response):
                        raw.write(json.dumps({'elapsed_s':time.perf_counter()-started, 'data':payload})+'\n')
                        raw.flush()
                        yield payload
                with urllib.request.urlopen(request, timeout=timeout) as response:
                    record['status'] = response.status
                    record['headers'] = dict(response.headers)
                    record['response'] = collect(payloads(response), started)
            after = metrics(base)
            (output/(name+'-metrics-after.txt')).write_text(after)
            record['mtp_after'] = after_values = metric_values(after, model)
            record['mtp_round_delta'] = after_values.get('mtp_rounds_total', 0)-before_values.get('mtp_rounds_total', 0)
            record['cache_inventory_after'] = inventory(cache_root)
            record['cache_inventory_unchanged'] = record['cache_inventory_after'] == before_inventory
            response = record['response']
            usage = response['usage']
            cached = (usage.get('prompt_tokens_details') or {}).get('cached_tokens')
            record['cached_tokens'] = cached
            record['cold_cache_explicitly_observed'] = cached == 0 if cached is not None else None
            checks = {'http_ok': record['status'] == 200,
                      'active_slot': after_values.get('mtp_active') == 1,
                      'usage_consistent': usage.get('total_tokens') == usage['prompt_tokens']+usage['completion_tokens']}
            if name.startswith('vision'):
                checks.update(visible_answer=bool(response['text'].strip()),
                              natural_stop=response['finish_reasons'] == ['stop'],
                              actual_mtp_rounds=record['mtp_round_delta'] > 0,
                              no_reported_cache_hit=cached is None or cached == 0)
            else:
                calls = record['tool_calls'] = tool_calls(response)
                expected = len(calls) == 1
                if expected:
                    call = next(iter(calls.values()))
                    expected = call['name'] == 'record_color' and json.loads(call['arguments']) == {'color':'blue', 'count':2}
                checks.update(tool_finish=response['finish_reasons'] == ['tool_calls'], exact_tool_call=expected)
            record['checks'] = checks
            record['passed'] = all(checks.values())
            (output/(name+'.json')).write_text(json.dumps(record, indent=2))
        report['passed'] = len(records) == 3 and all(r.get('passed') for r in records)
        report['cold_cache_http_evidence_complete'] = all(r.get('cold_cache_explicitly_observed') is True for r in records if r['name'].startswith('vision'))
    except Exception as error:
        report['error'] = repr(error)
    finally:
        (output/'report.json').write_text(json.dumps(report, indent=2))
    return report
