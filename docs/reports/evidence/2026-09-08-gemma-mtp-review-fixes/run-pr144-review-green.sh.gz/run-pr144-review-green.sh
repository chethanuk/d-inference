#!/bin/bash
set -euo pipefail
root=/Users/gaj/autoresearch/gemma-qat-prefix-cache-20260908
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
python3 - "$root" <<'VERIFY'
import sys,json,tarfile,pathlib,hashlib,shutil
root=pathlib.Path(sys.argv[1]); source=root/'workspace/libs/mlx-swift-lm'
with tarfile.open(root/'pr144-review-fixes.tar.gz') as archive: archive.extractall(source)
manifest=json.loads((root/'pr144-review-source-manifest.json').read_text())
for f in manifest['files']:
 p=source/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
 if f['path'].startswith('Tests/'):
  dest=root/'native-tests-harness5'/f['path'];shutil.copy2(p,dest)
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==f['sha256']
(root/'pr144-review-source-verification.json').write_text(json.dumps({'baseline_native':manifest['baseline_native'],'changed_files_verified':len(manifest['files']),'mismatches':[]},indent=2)+'\n')
VERIFY
cd "$root/native-tests-harness5"
xcrun swift build --force-resolved-versions -c release --build-tests --scratch-path "$root/release-build" --jobs 4 -Xswiftc -enable-testing > "$root/logs/pr144-review-green-build.log" 2>&1
cp -c "$root/candidate5-artifact/mlx.metallib" "$root/release-build/arm64-apple-macosx/release/GemmaPrefixNativeTestsPackageTests.xctest/Contents/MacOS/mlx.metallib"
xcrun swift test --force-resolved-versions -c release --skip-build --scratch-path "$root/release-build" --no-parallel -Xswiftc -enable-testing --filter 'CBv2MTPRoundSmokeTests|CBv2MTPEngineMixedTests|CBv2MTPCaptureFenceTests|CBv2MTPKVStaging|CBv2MTPRectangularDegradeTests|CBv2PagedQueryBlockingTests|CBv2PagedSpeculativeRowTests|CBv2QwenMTPIntegrationTests|CBv2MTPCaptureVerifyTests|HistoricalWindowCheckpointTests|HistoricalWindowCheckpointEngineTests|PagedCompleteCheckpointCodecTests|CBv2CompleteCheckpointEngineTests|CompleteCheckpointMetadataOwnershipTests|CBv2MTPCommittedDecodeBaselineTests|CBv2MTPDepthControllerTests|CBv2MTPCommittedGoodputTests|CBv2MTPWorkloadLifecycleTests|GatedDeltaTests' > "$root/logs/pr144-review-green-tests.log" 2>&1
